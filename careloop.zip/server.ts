import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';
import Razorpay from 'razorpay';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Razorpay Order Creation Endpoint
app.post('/api/razorpay/create-order', async (req, res) => {
  const { amount, currency = 'INR' } = req.body;
  if (!amount || typeof amount !== 'number') {
    return res.status(400).json({ error: 'Amount is required and must be a number.' });
  }

  try {
    const keyId = process.env.RAZORPAY_KEY_ID;
    const keySecret = process.env.RAZORPAY_KEY_SECRET;

    if (!keyId || !keySecret) {
      return res.json({
        isTestMode: true,
        message: 'Razorpay keys (RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET) are not configured in environment. Operating in sandbox/simulator mode.'
      });
    }

    // Initialize Razorpay client
    // @ts-ignore
    const razorClient = new Razorpay({
      key_id: keyId,
      key_secret: keySecret
    });

    const options = {
      amount: Math.round(amount * 100), // convert to paisa
      currency,
      receipt: 'rcpt_' + Math.random().toString(36).substring(2, 10),
    };

    const order = await razorClient.orders.create(options);
    res.json({
      isTestMode: false,
      keyId,
      orderId: order.id,
      amount: order.amount,
      currency: order.currency
    });
  } catch (error: any) {
    console.error('Razorpay Order Creation Error:', error);
    res.status(500).json({
      error: 'Failed to create Razorpay order.',
      details: error.message || error
    });
  }
});

// Initialize Gemini SDK with telemetry header
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.warn('WARNING: GEMINI_API_KEY environment variable is not set.');
  }
  return new GoogleGenAI({
    apiKey: apiKey || '',
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

// Simplify clinical notes API endpoint
app.post('/api/simplify-notes', async (req, res) => {
  const { notes } = req.body;

  if (!notes || typeof notes !== 'string') {
    return res.status(400).json({ error: 'Notes field is required and must be a string.' });
  }

  try {
    const ai = getGeminiClient();
    
    const prompt = `You are an empathetic, expert patient care coordinator. Take the following doctor's raw clinical notes and prescriptions, and translate them into simple, warm, patient-friendly language.

Raw doctor's notes:
"${notes}"

Please perform these translations:
1. Translate all shorthand (e.g., "po", "bid", "qd", "prn", "Rx", "qd prn", "pc", "ac", "q4-6h") and medical jargon into plain, clear, friendly English.
2. Structure all medications prescribed into list items, determining which daily slots ("morning", "afternoon", "evening") are appropriate based on the frequency.
3. Calculate or estimate the suggested follow-up period in days (e.g. "3 days" -> 3, "2 weeks" -> 14, "follow up next month" -> 30). If no follow-up is mentioned, set suggestedFollowUpDays to 0.

Ensure your entire explanation is clear, encouraging, and written directly to the patient. Do not use markdown inside the simplifiedText parameter itself — just return a warm, clean text format.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            simplifiedText: {
              type: Type.STRING,
              description: 'Clear, compassionate, patient-facing explanation of the diagnosis, care guidelines, and general instructions in plain English.',
            },
            medications: {
              type: Type.ARRAY,
              description: 'List of medications mentioned in the notes.',
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING, description: 'Name of the medication' },
                  dosage: { type: Type.STRING, description: 'Dosage details (e.g., 500mg, 1 tablet, 1 puff)' },
                  frequency: { type: Type.STRING, description: 'How often to take (e.g., twice daily, once at bedtime)' },
                  duration: { type: Type.STRING, description: 'How many days/weeks to take it (e.g., 7 days, 10 days, as needed)' },
                  slots: {
                    type: Type.ARRAY,
                    description: 'Time slots of the day when this should be taken. Must contain only "morning", "afternoon", or "evening".',
                    items: { type: Type.STRING },
                  },
                },
                required: ['name', 'dosage', 'frequency', 'duration', 'slots'],
              },
            },
            suggestedFollowUpDays: {
              type: Type.INTEGER,
              description: 'Days until follow-up appointment (integer). Set to 0 if none is indicated.',
            },
          },
          required: ['simplifiedText', 'medications', 'suggestedFollowUpDays'],
        },
      },
    });

    const resultText = response.text;
    if (!resultText) {
      throw new Error('Empty response from Gemini AI');
    }

    const data = JSON.parse(resultText);
    res.json(data);
  } catch (error: any) {
    console.error('Error with Gemini AI notes simplification:', error);
    res.status(500).json({
      error: 'Failed to simplify notes using AI. Please verify your API key is correctly configured.',
      details: error.message || error,
    });
  }
});

// AI Prescription Image/Document Analyzer Endpoint
app.post('/api/analyze-prescription', async (req, res) => {
  const { fileData, mimeType: clientMimeType } = req.body;

  if (!fileData) {
    return res.status(400).json({ error: 'File data is required. Please upload an image of your prescription.' });
  }

  try {
    let base64Data = fileData;
    let mimeType = clientMimeType || 'image/jpeg';

    // If it's a data URI (e.g. data:image/png;base64,iVBORw0KGgo...)
    if (fileData.startsWith('data:')) {
      const matches = fileData.match(/^data:([^;]+);base64,(.+)$/);
      if (matches && matches.length === 3) {
        mimeType = matches[1];
        base64Data = matches[2];
      }
    }

    const ai = getGeminiClient();

    const imagePart = {
      inlineData: {
        mimeType: mimeType,
        data: base64Data,
      },
    };

    const textPart = {
      text: `Analyze the uploaded prescription document/image.
Extract all medications/prescriptions listed.
For each medication, you must extract:
1. medicationName (string) - the clear brand or generic name of the medicine.
2. dosage (string) - the dosage strength or amount (e.g., '500mg', '1 tablet', '2 drops', '1 puff').
3. frequency (string) - how often it is taken (e.g., 'Once daily', 'Twice daily', 'Three times a day', 'Every 8 hours', 'As needed').
4. duration (string) - how long to take it (e.g., '5 days', '1 week', 'Chronic', '30 days'). Default to 'As directed' if not specified.
5. slot (string) - must be strictly one of: 'morning', 'afternoon', 'evening'. Choose the most logical single slot based on standard clinical practices (e.g., once daily or once morning -> 'morning', bid or twice daily -> 'morning', tid -> split or choose 'morning', evening/night -> 'evening').
6. instructions (string) - special directions (e.g., 'Take after food', 'Take on empty stomach', 'Avoid dairy').

Return the extracted list of medications strictly as a JSON array of objects conforming to this schema.`,
    };

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: [imagePart, textPart],
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              medicationName: { type: Type.STRING },
              dosage: { type: Type.STRING },
              frequency: { type: Type.STRING },
              duration: { type: Type.STRING },
              slot: { type: Type.STRING, description: "Must be strictly one of: 'morning', 'afternoon', 'evening'" },
              instructions: { type: Type.STRING },
            },
            required: ['medicationName', 'dosage', 'frequency', 'duration', 'slot', 'instructions'],
          },
        },
      },
    });

    const resultText = response.text;
    if (!resultText) {
      throw new Error('No content returned from Gemini AI.');
    }

    const medications = JSON.parse(resultText);
    res.json({ medications });
  } catch (error: any) {
    console.error('Error with prescription analyzer:', error);
    res.status(500).json({
      error: 'Failed to analyze prescription using AI. Please verify your API key is correctly configured and the image is clear.',
      details: error.message || error,
    });
  }
});

// ==========================================
// WhatsApp Adherence & Reminder Engine
// ==========================================

interface WhatsAppMessage {
  id: string;
  phone: string;
  patientName: string;
  medicationName: string;
  dosage: string;
  slot: string;
  body: string;
  timestamp: string;
  reminderIndex: number; // 1, 2, or 3
  status: 'sent' | 'pending_delay' | 'cancelled_taken';
  scheduledTimeMs: number;
  twilioSid?: string;
  twilioError?: string;
}

let messagesLog: WhatsAppMessage[] = [];
let pendingReminders: WhatsAppMessage[] = [];

// Helper to send actual Twilio WhatsApp message
async function sendActualWhatsApp(to: string, body: string) {
  const sid = process.env.TWILIO_ACCOUNT_SID;
  const token = process.env.TWILIO_AUTH_TOKEN;
  const fromNum = process.env.TWILIO_SENDER_NUMBER || '+14155238886';

  if (!sid || !token) {
    console.log(`[SIMULATED WHATSAPP TO ${to}]: ${body}`);
    return { isSimulated: true, status: 'logged' };
  }

  let formattedTo = to.trim();
  if (!formattedTo.startsWith('+')) {
    formattedTo = '+' + formattedTo;
  }

  const fromStr = fromNum.startsWith('whatsapp:') ? fromNum : `whatsapp:${fromNum}`;
  const toStr = `whatsapp:${formattedTo}`;
  const auth = Buffer.from(`${sid}:${token}`).toString('base64');

  try {
    const params = new URLSearchParams();
    params.append('From', fromStr);
    params.append('To', toStr);
    params.append('Body', body);

    const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${auth}`,
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: params.toString()
    });

    const resData = await response.json();
    console.log('[TWILIO RESPONSE]', resData);
    return { isSimulated: false, twilioSid: resData.sid, error: resData.message };
  } catch (err: any) {
    console.error('Twilio Outbound Fetch Error:', err);
    return { isSimulated: false, error: err.message };
  }
}

// Background poller for real-time elapsed delays (fires every 5 seconds)
setInterval(async () => {
  const now = Date.now();
  for (let i = pendingReminders.length - 1; i >= 0; i--) {
    const r = pendingReminders[i];
    if (r.status === 'pending_delay' && r.scheduledTimeMs <= now) {
      r.status = 'sent';
      r.timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      messagesLog.push({ ...r });
      await sendActualWhatsApp(r.phone, r.body);
      pendingReminders.splice(i, 1);
    }
  }
}, 5000);

// 1. Trigger Missed Dose & Outbound alerts
app.post('/api/whatsapp/trigger-missed-dose', async (req, res) => {
  const { patientName, patientPhone, medicationName, dosage, slot, webLink } = req.body;

  if (!patientPhone) {
    return res.status(400).json({ error: 'Patient phone number is required.' });
  }

  const name = patientName || 'Patient';
  const phone = patientPhone;
  const med = medicationName || 'Medication';
  const dose = dosage || 'Prescribed dose';
  const slt = slot || 'scheduled slot';
  const link = webLink || 'https://careloop.health';

  const nowMs = Date.now();

  // Create Reminder 1 (Immediate)
  const rem1Text = `⚠️ *CareLoop Adherence Alert* ⚠️\n\nHi *${name}*, you missed your daily dose of *${med}* (${dose}) scheduled for the *${slt}*!\n\nPlease take it now to stay safe. Confirm your intake and log it in your patient portal:\n👉 ${link}`;
  
  const msg1: WhatsAppMessage = {
    id: 'wa-' + Math.random().toString(36).substring(2, 9),
    phone,
    patientName: name,
    medicationName: med,
    dosage: dose,
    slot: slt,
    body: rem1Text,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    reminderIndex: 1,
    status: 'sent',
    scheduledTimeMs: nowMs
  };

  messagesLog.push(msg1);
  const twilioResult = await sendActualWhatsApp(phone, rem1Text);

  // Clear existing pending reminders for this medication to avoid duplicate alert cascades
  pendingReminders = pendingReminders.filter(r => !(r.phone === phone && r.medicationName === med));

  // Create Reminder 2 (+5 Min Gap)
  const rem2Text = `⏳ *CareLoop Reminder [2/3]* ⏳\n\nHi *${name}*, 5 minutes have elapsed and you still haven't marked *${med}* as taken!\n\nIt's crucial to stick to your schedule. Log your dose here:\n👉 ${link}`;
  const msg2: WhatsAppMessage = {
    id: 'wa-' + Math.random().toString(36).substring(2, 9),
    phone,
    patientName: name,
    medicationName: med,
    dosage: dose,
    slot: slt,
    body: rem2Text,
    timestamp: '',
    reminderIndex: 2,
    status: 'pending_delay',
    scheduledTimeMs: nowMs + 5 * 60 * 1000 // +5 minutes
  };
  pendingReminders.push(msg2);

  // Create Reminder 3 (+10 Min Gap)
  const rem3Text = `🚨 *CareLoop Critical Alert [3/3]* 🚨\n\nHi *${name}*, this is your final reminder! It has been 10 minutes since your missed *${med}* dose.\n\nPlease verify your adherence immediately to prevent clinical complications:\n👉 ${link}`;
  const msg3: WhatsAppMessage = {
    id: 'wa-' + Math.random().toString(36).substring(2, 9),
    phone,
    patientName: name,
    medicationName: med,
    dosage: dose,
    slot: slt,
    body: rem3Text,
    timestamp: '',
    reminderIndex: 3,
    status: 'pending_delay',
    scheduledTimeMs: nowMs + 10 * 60 * 1000 // +10 minutes
  };
  pendingReminders.push(msg3);

  res.json({
    success: true,
    message: 'Reminder cascade initiated. 1st WhatsApp sent. 2nd and 3rd scheduled with 5-min intervals.',
    firstMessage: msg1,
    twilioResult
  });
});

// 1b. Trigger Login Confirmation SMS/WhatsApp
app.post('/api/whatsapp/send-login-confirmation', async (req, res) => {
  const { patientName, patientPhone, webLink } = req.body;

  if (!patientPhone) {
    return res.status(400).json({ error: 'Patient phone number is required.' });
  }

  const name = patientName || 'Patient';
  const phone = patientPhone;
  const link = webLink || 'https://careloop.health';

  const nowMs = Date.now();
  const confirmationText = `🔐 *CareLoop Portal Login Confirmation* 🔐\n\nHi *${name}*,\n\nYou have successfully logged into your CareLoop Patient Portal on ${new Date().toLocaleDateString()}!\n\nUse this link to access your clinical timeline, manage prescriptions, and track daily reminders anytime:\n👉 ${link}\n\nStay healthy!\n- CareLoop Team`;

  const msg: WhatsAppMessage = {
    id: 'wa-login-' + Math.random().toString(36).substring(2, 9),
    phone,
    patientName: name,
    medicationName: 'Login Security',
    dosage: 'N/A',
    slot: 'Security Alert',
    body: confirmationText,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    reminderIndex: 1,
    status: 'sent',
    scheduledTimeMs: nowMs
  };

  messagesLog.push(msg);
  const twilioResult = await sendActualWhatsApp(phone, confirmationText);

  res.json({
    success: true,
    message: 'Login confirmation WhatsApp sent successfully.',
    messageLogged: msg,
    twilioResult
  });
});

// 2. Fetch Logs
app.get('/api/whatsapp/logs', (req, res) => {
  const { phone } = req.query;
  let filtered = messagesLog;
  if (phone) {
    filtered = messagesLog.filter(m => m.phone === String(phone));
  }
  res.json({
    logs: filtered,
    pendingCount: pendingReminders.filter(r => !phone || r.phone === String(phone)).length,
    pendingList: pendingReminders.filter(r => !phone || r.phone === String(phone))
  });
});

// 3. Fast Forward 5 Mins (Dispatches the earliest pending message instantly)
app.post('/api/whatsapp/fast-forward', async (req, res) => {
  const { phone } = req.body;
  
  // Find earliest pending reminder for this phone (or any)
  const index = pendingReminders.findIndex(r => r.status === 'pending_delay' && (!phone || r.phone === String(phone)));
  
  if (index === -1) {
    return res.json({
      success: false,
      message: 'No pending delayed reminders are currently scheduled.'
    });
  }

  // Retrieve the reminder
  const r = pendingReminders[index];
  
  // Dispatch it
  r.status = 'sent';
  r.timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  messagesLog.push({ ...r });
  
  const twilioRes = await sendActualWhatsApp(r.phone, r.body);

  // Remove from pending list
  pendingReminders.splice(index, 1);

  res.json({
    success: true,
    message: `Simulated time advanced by 5 minutes. Dispatching Reminder #${r.reminderIndex} for ${r.medicationName}!`,
    dispatchedMessage: r,
    twilioRes
  });
});

// 4. Cancel Pending (when medication is checked/taken)
app.post('/api/whatsapp/clear-pending', (req, res) => {
  const { phone, medicationName } = req.body;
  if (!phone || !medicationName) {
    return res.status(400).json({ error: 'Phone and medicationName are required.' });
  }

  const initialCount = pendingReminders.length;
  pendingReminders = pendingReminders.filter(r => !(r.phone === String(phone) && r.medicationName === medicationName));
  const removedCount = initialCount - pendingReminders.length;

  res.json({
    success: true,
    message: `Cancelled ${removedCount} pending delayed reminders for ${medicationName}. No further alerts will be sent.`,
    removedCount
  });
});

// 5. Reset Logs and Scheduler
app.post('/api/whatsapp/reset', (req, res) => {
  messagesLog = [];
  pendingReminders = [];
  res.json({ success: true, message: 'All WhatsApp simulator logs and active schedulers have been reset.' });
});

// Setup Vite development server or serve built assets in production
async function setupServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
    console.log('Vite middleware loaded in DEVELOPMENT mode');
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
    console.log('Serving static files from dist in PRODUCTION mode');
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

setupServer();
