import React, { useState } from 'react';
import { Doctor, Appointment, Visit, SymptomCheckIn, MedicationTask, CareState } from './types';
import {
  SAMPLE_DOCTORS,
  SAMPLE_APPOINTMENTS,
  SAMPLE_VISITS,
  SAMPLE_MEDICATION_TASKS,
  SAMPLE_CHECKINS,
} from './sampleData';
import BookAppointment from './components/BookAppointment';
import MyTimeline from './components/MyTimeline';
import Reminders from './components/Reminders';
import SymptomCheckInView from './components/SymptomCheckIn';
import DoctorDashboard from './components/DoctorDashboard';
import PharmacyDashboard from './components/PharmacyDashboard';
import PatientLogin from './components/PatientLogin';
import {
  Calendar,
  Clock,
  Sparkles,
  Heart,
  Activity,
  FileText,
  CheckCircle2,
  Bell,
  HeartPulse,
  Award,
  Stethoscope,
  ShieldCheck,
  LogOut,
} from 'lucide-react';

export default function App() {
  const [activePortal, setActivePortal] = useState<'patient' | 'doctor' | 'pharmacy'>('patient');
  const [activeTab, setActiveTab] = useState<'booking' | 'timeline' | 'reminders' | 'checkin'>('booking');

  // Unified State
  const [currentUser, setCurrentUser] = useState<{ name: string; phone: string } | null>(() => {
    const saved = localStorage.getItem('careloop_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [loginAlert, setLoginAlert] = useState<{ show: boolean; phone: string; name: string } | null>(null);

  const handleLogin = (name: string, phone: string, linkWhatsApp: boolean = true) => {
    const user = { name, phone };
    setCurrentUser(user);
    localStorage.setItem('careloop_user', JSON.stringify(user));
    
    if (linkWhatsApp) {
      setLoginAlert({ show: true, phone, name });

      // Send login confirmation WhatsApp message
      fetch('/api/whatsapp/send-login-confirmation', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          patientName: name,
          patientPhone: phone,
          webLink: window.location.href,
        }),
      })
        .then((res) => res.json())
        .then((data) => {
          console.log('Login confirmation response:', data);
        })
        .catch((err) => {
          console.error('Failed to send login confirmation:', err);
        });
    } else {
      setLoginAlert(null);
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('careloop_user');
    setLoginAlert(null);
  };

  const [doctors] = useState<Doctor[]>(SAMPLE_DOCTORS);
  const [appointments, setAppointments] = useState<Appointment[]>(SAMPLE_APPOINTMENTS);
  const [visits, setVisits] = useState<Visit[]>(SAMPLE_VISITS);
  const [checkIns, setCheckIns] = useState<SymptomCheckIn[]>(SAMPLE_CHECKINS);
  const [medicationTasks, setMedicationTasks] = useState<MedicationTask[]>(SAMPLE_MEDICATION_TASKS);
  const [simplifiedNotesText, setSimplifiedNotesText] = useState<string | undefined>(undefined);
  const [curedMedications, setCuredMedications] = useState<string[]>([]);

  // Emergency Surgery Timing State
  const [surgeryTimings, setSurgeryTimings] = useState<Record<string, {
    isEmergencyActive: boolean;
    startTime: string;
    endTime: string;
    note: string;
  }>>(() => {
    try {
      const saved = localStorage.getItem('careloop_surgery_timings');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const handleUpdateSurgeryTiming = (doctorId: string, timing: {
    isEmergencyActive: boolean;
    startTime: string;
    endTime: string;
    note: string;
  }) => {
    setSurgeryTimings((prev) => {
      const updated = { ...prev, [doctorId]: timing };
      localStorage.setItem('careloop_surgery_timings', JSON.stringify(updated));
      return updated;
    });
  };

  // Core handlers
  const handleBookAppointment = (doctorId: string, date: string, slot: string, paymentId?: string, amountPaid?: number) => {
    const doctor = doctors.find((d) => d.id === doctorId);
    if (!doctor) return;

    const newAppt: Appointment = {
      id: 'appt-' + Math.random().toString(36).substring(2, 9),
      doctorId,
      doctorName: doctor.name,
      specialty: doctor.specialty,
      date,
      slot,
      status: 'upcoming',
      paymentId,
      amountPaid,
    };

    setAppointments((prev) => [newAppt, ...prev]);
  };

  const handleAddVisit = (newVisit: Visit) => {
    setVisits((prev) => [newVisit, ...prev]);

    // Create daily medication tasks from this newly analyzed visit!
    const newTasks: MedicationTask[] = [];
    newVisit.medications.forEach((med) => {
      med.slots.forEach((slot) => {
        newTasks.push({
          id: 'task-' + Math.random().toString(36).substring(2, 9),
          medicationName: med.name,
          dosage: med.dosage,
          slot: slot,
          checked: false,
        });
      });
    });

    setMedicationTasks((prev) => [...newTasks, ...prev]);

    // Complete the linked appointment status if it was linked
    if (newVisit.doctorId !== 'doc-custom') {
      setAppointments((prev) =>
        prev.map((appt) =>
          appt.doctorId === newVisit.doctorId && appt.date === newVisit.date
            ? { ...appt, status: 'completed' }
            : appt
        )
      );
    }
  };

  const handleRemoveVisit = (visitId: string) => {
    setVisits((prev) => prev.filter((v) => v.id !== visitId));
  };

  const handleToggleTask = (taskId: string) => {
    setMedicationTasks((prev) => {
      const updated = prev.map((task) => (task.id === taskId ? { ...task, checked: !task.checked } : task));
      const targetTask = updated.find(t => t.id === taskId);
      
      if (targetTask && targetTask.checked && currentUser) {
        fetch('/api/whatsapp/clear-pending', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            phone: currentUser.phone,
            medicationName: targetTask.medicationName
          })
        }).then(res => res.json())
          .then(data => console.log('Successfully cancelled pending delayed alerts:', data))
          .catch(err => console.error('Error clearing alerts:', err));
      }
      return updated;
    });
  };

  const handleResetTasks = () => {
    setMedicationTasks((prev) => prev.map((task) => ({ ...task, checked: false })));
  };

  const handleAddMedications = (newMeds: Array<{ medicationName: string; dosage: string; slot: string }>) => {
    const newTasks: MedicationTask[] = newMeds.map((med) => ({
      id: 'task-' + Math.random().toString(36).substring(2, 9),
      medicationName: med.medicationName,
      dosage: med.dosage,
      slot: (['morning', 'afternoon', 'evening'].includes(med.slot) ? med.slot : 'morning') as 'morning' | 'afternoon' | 'evening',
      checked: false,
    }));
    setMedicationTasks((prev) => [...newTasks, ...prev]);
  };

  const handleCureMedication = (medicationName: string) => {
    setMedicationTasks((prev) => prev.filter((task) => task.medicationName !== medicationName));
    setCuredMedications((prev) => [...prev, medicationName]);
  };

  const handleAddCheckIn = (rating: number, note: string) => {
    const todayStr = '2026-07-05';
    const newCheckIn: SymptomCheckIn = {
      date: todayStr,
      rating,
      note,
    };

    setCheckIns((prev) => [newCheckIn, ...prev.filter((c) => c.date !== todayStr)]);
  };

  // Check if follow-up recommendation banner needs attention (<= 3 days left from July 5th, 2026)
  const isFollowUpDueSoon = (): boolean => {
    const today = new Date('2026-07-05');
    return visits.some((visit) => {
      if (!visit.followUpDate) return false;
      const followUp = new Date(visit.followUpDate);
      const diffTime = followUp.getTime() - today.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays >= 0 && diffDays <= 3;
    });
  };

  // Check if rating drops for 3+ consecutive days
  const hasDeclineAlert = (): boolean => {
    if (checkIns.length < 3) return false;
    const sorted = [...checkIns].sort((a, b) => a.date.localeCompare(b.date));
    const n = sorted.length;
    return sorted[n - 3].rating > sorted[n - 2].rating && sorted[n - 2].rating > sorted[n - 1].rating;
  };

  const upcomingAppts = appointments.filter((appt) => appt.status === 'upcoming');
  const incompleteTasksCount = medicationTasks.filter((t) => !t.checked).length;

  return (
    <div className="min-h-screen bg-slate-50/50 flex flex-col font-sans text-slate-700 selection:bg-teal-100 selection:text-teal-900" id="careloop-app">
      
      {/* Top Clinical Portal Selector utility bar */}
      <div className="bg-slate-900 text-slate-200 px-6 py-2 border-b border-slate-800 text-xs shadow-sm" id="portal-bar">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 font-bold tracking-wide">
            <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse"></span>
            <span>CareLoop Multidisciplinary Workspace</span>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-bold text-slate-400 mr-1.5 text-[11px] uppercase tracking-wider">Switch Workspace:</span>
            <div className="flex bg-slate-800 rounded-lg p-0.5 border border-slate-700/60 shadow-inner">
              <button
                onClick={() => setActivePortal('patient')}
                className={`px-3 py-1 text-[11px] font-bold rounded-md transition-all cursor-pointer ${
                  activePortal === 'patient'
                    ? 'bg-brand-primary text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                id="portal-btn-patient"
              >
                Patient Portal
              </button>
              <button
                onClick={() => setActivePortal('doctor')}
                className={`px-3 py-1 text-[11px] font-bold rounded-md transition-all cursor-pointer ${
                  activePortal === 'doctor'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                id="portal-btn-doctor"
              >
                Doctor Workstation
              </button>
              <button
                onClick={() => setActivePortal('pharmacy')}
                className={`px-3 py-1 text-[11px] font-bold rounded-md transition-all cursor-pointer ${
                  activePortal === 'pharmacy'
                    ? 'bg-slate-700 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                id="portal-btn-pharmacy"
              >
                Pharmacy Hub
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Top Professional Navigation Header */}
      <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-slate-100 px-6 py-4.5" id="app-header">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
          
          {/* Logo and App Identity */}
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 bg-brand-primary rounded-2xl flex items-center justify-center text-white shadow-md shadow-brand-primary/10 border border-brand-primary/10">
              <HeartPulse className="w-6 h-6 animate-pulse-slow" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold text-brand-text-dark tracking-tight">CareLoop</h1>
                <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full uppercase border transition-all ${
                  activePortal === 'patient'
                    ? 'bg-brand-primary-light text-brand-primary border-brand-primary/20'
                    : activePortal === 'doctor'
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-250'
                    : 'bg-slate-100 text-slate-700 border-slate-250'
                }`}>
                  {activePortal === 'patient' ? 'Patient Portal' : activePortal === 'doctor' ? 'Clinical Portal' : 'Pharmacy Hub'}
                </span>
              </div>
              <p className="text-xs text-brand-text-muted font-medium">Healthcare Tracker & AI Coordinator</p>
            </div>
          </div>

          {/* Navigation Tabs (Only rendered when on Patient Portal) */}
          {activePortal === 'patient' ? (
            <nav className="flex items-center bg-slate-50 border border-brand-border p-1 rounded-2xl md:max-w-lg w-full md:w-auto animate-fade-in" id="app-nav-tabs">
              <button
                onClick={() => setActiveTab('booking')}
                className={`flex-1 md:flex-none px-4 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  activeTab === 'booking'
                    ? 'bg-brand-primary text-white border border-brand-primary/20 shadow-sm shadow-brand-primary/10'
                    : 'text-brand-text-muted hover:text-brand-primary hover:bg-brand-primary-light'
                }`}
                id="tab-booking"
              >
                <Calendar className="w-3.5 h-3.5" />
                Book Slot
              </button>
              <button
                onClick={() => setActiveTab('timeline')}
                className={`flex-1 md:flex-none px-4 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer relative ${
                  activeTab === 'timeline'
                    ? 'bg-brand-primary text-white border border-brand-primary/20 shadow-sm shadow-brand-primary/10'
                    : 'text-brand-text-muted hover:text-brand-primary hover:bg-brand-primary-light'
                }`}
                id="tab-timeline"
              >
                <FileText className="w-3.5 h-3.5" />
                Timeline
                {visits.length > 0 && (
                  <span className={`absolute -top-1.5 -right-1 text-[9px] font-bold w-4.5 h-4.5 rounded-full flex items-center justify-center border transition-all ${
                    activeTab === 'timeline'
                      ? 'bg-white text-brand-primary border-brand-primary/10'
                      : 'bg-brand-primary text-white border-white'
                  }`}>
                    {visits.length}
                  </span>
                )}
              </button>
              <button
                onClick={() => setActiveTab('reminders')}
                className={`flex-1 md:flex-none px-4 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer relative ${
                  activeTab === 'reminders'
                    ? 'bg-brand-primary text-white border border-brand-primary/20 shadow-sm shadow-brand-primary/10'
                    : 'text-brand-text-muted hover:text-brand-primary hover:bg-brand-primary-light'
                }`}
                id="tab-reminders"
              >
                <Sparkles className="w-3.5 h-3.5" />
                Reminders
                {(isFollowUpDueSoon() || incompleteTasksCount > 0) && (
                  <span className={`absolute -top-1.5 -right-1 text-[9px] font-bold w-4.5 h-4.5 rounded-full flex items-center justify-center border transition-all ${
                    activeTab === 'reminders'
                      ? 'bg-white text-brand-primary border-brand-primary/10'
                      : isFollowUpDueSoon()
                      ? 'bg-amber-500 text-white border-white animate-pulse'
                      : 'bg-brand-primary text-white border-white'
                  }`}>
                    {isFollowUpDueSoon() ? '!' : incompleteTasksCount}
                  </span>
                )}
              </button>
              <button
                onClick={() => setActiveTab('checkin')}
                className={`flex-1 md:flex-none px-4 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer relative ${
                  activeTab === 'checkin'
                    ? 'bg-brand-primary text-white border border-brand-primary/20 shadow-sm shadow-brand-primary/10'
                    : 'text-brand-text-muted hover:text-brand-primary hover:bg-brand-primary-light'
                }`}
                id="tab-checkin"
              >
                <Activity className="w-3.5 h-3.5" />
                Check-In
                {hasDeclineAlert() && (
                  <span className="absolute -top-1 -right-1 bg-rose-500 w-2.5 h-2.5 rounded-full animate-ping"></span>
                )}
              </button>
            </nav>
          ) : (
            <div className="text-xs font-mono font-bold text-slate-400 border border-slate-100 rounded-xl px-3.5 py-1.5 flex items-center gap-2 bg-slate-50/50">
              <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
              <span>Role-restricted Secure Session</span>
            </div>
          )}

          {/* Current System Date Indicator & Patient Identity */}
          <div className="flex items-center gap-2 flex-wrap">
            {currentUser && activePortal === 'patient' && (
              <div className="flex items-center gap-2 text-xs flex-wrap" id="user-badge-container">
                <div className="flex items-center gap-1.5 border border-emerald-100 bg-emerald-50/50 rounded-xl px-3 py-1.5 text-emerald-950 font-bold">
                  <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                  <span className="text-[10px] uppercase font-black font-mono tracking-wider text-emerald-600">🔗 WhatsApp Linked</span>
                  <span className="text-slate-300">|</span>
                  <span className="font-mono">{currentUser.phone}</span>
                </div>
                
                <div className="flex items-center gap-1.5 border border-teal-100 bg-teal-50/40 rounded-xl px-3 py-1.5">
                  <span className="font-extrabold text-slate-850">
                    {currentUser.name}
                  </span>
                  <button
                    onClick={() => {
                      // Trigger another welcome message instantly
                      fetch('/api/whatsapp/send-login-confirmation', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                          patientName: currentUser.name,
                          patientPhone: currentUser.phone,
                          webLink: window.location.href
                        })
                      })
                      .then(res => res.json())
                      .then(data => {
                        alert(`📲 Instant Welcome Message Dispatched!\n\nSent immediately to your linked number: ${currentUser.phone}\n\nCheck the "WhatsApp Simulator" under the "Reminders" tab to view the live logs!`);
                      })
                      .catch(err => {
                        console.error('Error sending welcome message:', err);
                      });
                    }}
                    className="ml-1 text-teal-600 hover:text-teal-700 font-extrabold text-[10px] bg-teal-100/60 hover:bg-teal-100 px-1.5 py-0.5 rounded-md cursor-pointer transition-all uppercase font-mono"
                    title="Send test WhatsApp welcome message"
                  >
                    Test Send
                  </button>
                  <span className="text-slate-300 mx-0.5">|</span>
                  <button
                    onClick={handleLogout}
                    className="text-slate-400 hover:text-rose-600 transition-colors focus:outline-none cursor-pointer"
                    title="Logout Patient"
                    id="header-logout-btn"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}
            <div className="hidden lg:flex items-center gap-2 text-xs font-mono font-bold text-slate-400 border border-slate-100 rounded-xl px-3.5 py-1.5">
              <Clock className="w-3.5 h-3.5 text-slate-300" />
              <span>Today: 2026-07-05</span>
            </div>
          </div>

        </div>
      </header>

      {/* Main Dynamic View Content Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-6 md:p-8" id="main-content-panel">
        
        {/* Patient-facing active emergency surgery banner */}
        {activePortal === 'patient' && Object.keys(surgeryTimings).some((docId) => surgeryTimings[docId]?.isEmergencyActive) && (
          <div className="mb-6 p-4 bg-rose-50 border border-rose-150 rounded-2xl flex items-start gap-3 text-rose-800 animate-pulse" id="patient-emergency-alert">
            <div className="w-10 h-10 bg-rose-100 rounded-xl flex items-center justify-center shrink-0">
              <span className="text-lg">🚨</span>
            </div>
            <div className="text-left">
              <p className="text-xs font-black uppercase tracking-wider text-rose-600">Urgent Provider Notice</p>
              {Object.keys(surgeryTimings)
                .filter((docId) => surgeryTimings[docId]?.isEmergencyActive)
                .map((docId) => {
                  const doc = doctors.find((d) => d.id === docId);
                  const timing = surgeryTimings[docId];
                  if (!doc || !timing) return null;
                  return (
                    <p key={docId} className="text-xs text-rose-900 font-bold mt-0.5">
                      {doc.name} ({doc.specialty}) is currently in an unscheduled emergency surgery today from <span className="underline font-mono">{timing.startTime}</span> to <span className="underline font-mono">{timing.endTime}</span>. Timings may be delayed.
                      {timing.note && <span className="block text-[11px] font-medium text-rose-700 italic mt-0.5">Note: "{timing.note}"</span>}
                    </p>
                  );
                })}
            </div>
          </div>
        )}

        {activePortal === 'patient' && (
          <>
            {!currentUser ? (
              <PatientLogin onLogin={handleLogin} />
            ) : (
              <>
                {/* Patient-facing WhatsApp Link Verification Alert */}
                {loginAlert?.show && (
                  <div className="mb-6 p-5 bg-teal-50 border border-teal-200/80 rounded-2xl flex items-start justify-between gap-4 text-teal-900 animate-fade-in relative" id="patient-login-welcome-alert">
                    <div className="flex items-start gap-3 text-left">
                      <div className="w-10 h-10 bg-teal-100/80 rounded-xl flex items-center justify-center shrink-0">
                        <span className="text-lg">💬</span>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs font-black uppercase tracking-wider text-teal-600 font-mono">WhatsApp Verification Link Dispatched</p>
                        <p className="text-xs text-teal-950 font-bold">
                          Welcome to CareLoop, <span className="underline">{loginAlert.name}</span>!
                        </p>
                        <p className="text-[11px] text-teal-900 leading-relaxed font-medium max-w-2xl">
                          We have successfully dispatched an instant welcome verification message to your linked WhatsApp number <strong className="font-mono text-teal-950">{loginAlert.phone}</strong>. 
                          Please check your phone now to complete the secure verification.
                        </p>
                        <div className="pt-1.5 flex items-center gap-1.5">
                          <span className="inline-flex h-2 w-2 relative">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-2 w-2 bg-teal-500"></span>
                          </span>
                          <span className="text-[9px] font-extrabold text-teal-700 tracking-wider uppercase font-mono">Interactive link established</span>
                        </div>
                      </div>
                    </div>
                    <button 
                      onClick={() => setLoginAlert(null)}
                      className="text-teal-500 hover:text-teal-700 font-bold text-sm bg-teal-100/50 hover:bg-teal-150 px-2.5 py-1 rounded-xl transition-all cursor-pointer border border-teal-200/40"
                    >
                      ✕ Dismiss
                    </button>
                  </div>
                )}

                {activeTab === 'booking' && (
                  <BookAppointment
                    doctors={doctors}
                    appointments={appointments}
                    onBookAppointment={handleBookAppointment}
                    surgeryTimings={surgeryTimings}
                  />
                )}

                {activeTab === 'timeline' && (
                  <MyTimeline
                    visits={visits}
                    upcomingAppointments={upcomingAppts}
                    onAddVisit={handleAddVisit}
                    onRemoveVisit={handleRemoveVisit}
                    onUpdateSimplifiedNotesText={setSimplifiedNotesText}
                  />
                )}

                {activeTab === 'reminders' && (
                  <Reminders
                    visits={visits}
                    medicationTasks={medicationTasks}
                    onToggleTask={handleToggleTask}
                    onResetTasks={handleResetTasks}
                    simplifiedNotesText={simplifiedNotesText}
                    curedMedications={curedMedications}
                    onCureMedication={handleCureMedication}
                    currentUser={currentUser}
                    onAddMedications={handleAddMedications}
                  />
                )}

                {activeTab === 'checkin' && (
                  <SymptomCheckInView
                    checkIns={checkIns}
                    onAddCheckIn={handleAddCheckIn}
                  />
                )}
              </>
            )}
          </>
        )}

        {activePortal === 'doctor' && (
          <DoctorDashboard
            doctors={doctors}
            appointments={appointments}
            visits={visits}
            checkIns={checkIns}
            onAddVisit={handleAddVisit}
            surgeryTimings={surgeryTimings}
            onUpdateSurgeryTiming={handleUpdateSurgeryTiming}
          />
        )}

        {activePortal === 'pharmacy' && (
          <PharmacyDashboard
            visits={visits}
          />
        )}

      </main>

      {/* Trust & Compliance Footer */}
      <footer className="bg-white border-t border-slate-100 py-6 px-8 text-center text-[11px] text-slate-400" id="app-footer">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            <span>HIPAA Compliant Data Handling • End-to-End Encryption Enabled</span>
          </div>
          <div>© 2026 CareLoop. Engineered with Google Gemini 3.5. All rights reserved.</div>
        </div>
      </footer>
    </div>
  );
}
