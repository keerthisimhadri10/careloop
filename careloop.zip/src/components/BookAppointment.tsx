import React, { useState } from 'react';
import { Doctor, Appointment } from '../types';
import { 
  Calendar, Clock, Star, MapPin, CheckCircle2, User, Award, 
  ShieldCheck, CreditCard, AlertTriangle, Loader2, ArrowLeft,
  AlertCircle
} from 'lucide-react';

interface BookAppointmentProps {
  doctors: Doctor[];
  appointments: Appointment[];
  onBookAppointment: (doctorId: string, date: string, slot: string, paymentId?: string, amountPaid?: number) => void;
  surgeryTimings?: Record<string, {
    isEmergencyActive: boolean;
    startTime: string;
    endTime: string;
    note: string;
  }>;
}

export default function BookAppointment({
  doctors,
  appointments,
  onBookAppointment,
  surgeryTimings,
}: BookAppointmentProps) {
  const [selectedDoctorId, setSelectedDoctorId] = useState<string | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>('2026-07-06'); // default to next day
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
  
  // Navigation & checkout states
  const [showPaymentReview, setShowPaymentReview] = useState<boolean>(false);
  const [isProcessingPayment, setIsProcessingPayment] = useState<boolean>(false);
  const [showMockRazorpayModal, setShowMockRazorpayModal] = useState<boolean>(false);
  const [paymentError, setPaymentError] = useState<string>('');
  
  const [showConfirmation, setShowConfirmation] = useState<boolean>(false);
  const [lastBookedAppt, setLastBookedAppt] = useState<Appointment | null>(null);

  const selectedDoctor = doctors.find((d) => d.id === selectedDoctorId);

  // Billing calculation
  const consultationFee = 500;
  const gst = 90; // 18% of 500
  const totalAmount = consultationFee + gst;

  // Helper to check if a day of week is available for the doctor
  const getDayOfWeekName = (dateStr: string): string => {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const date = new Date(dateStr);
    return days[date.getUTCDay()];
  };

  const isDayAvailable = selectedDoctor
    ? selectedDoctor.availableDays.includes(getDayOfWeekName(selectedDate))
    : false;

  // Check if a specific slot is already booked for this doctor on this date
  const isSlotBooked = (slotName: string): boolean => {
    if (!selectedDoctorId) return false;
    return appointments.some(
      (appt) =>
        appt.doctorId === selectedDoctorId &&
        appt.date === selectedDate &&
        appt.slot === slotName &&
        appt.status === 'upcoming'
    );
  };

  // Triggers final booking confirmation
  const handleFinalizeBooking = (paymentId: string) => {
    if (!selectedDoctorId || !selectedDate || !selectedSlot) return;

    onBookAppointment(selectedDoctorId, selectedDate, selectedSlot, paymentId, totalAmount);

    const newAppt: Appointment = {
      id: 'appt-' + Math.random().toString(36).substring(2, 9),
      doctorId: selectedDoctorId,
      doctorName: selectedDoctor?.name || '',
      specialty: selectedDoctor?.specialty || '',
      date: selectedDate,
      slot: selectedSlot,
      status: 'upcoming',
      paymentId: paymentId,
      amountPaid: totalAmount,
    };

    setLastBookedAppt(newAppt);
    setShowConfirmation(true);
    setShowPaymentReview(false);
    setShowMockRazorpayModal(false);
    setSelectedSlot(null);
  };

  // Starts the Razorpay payment gateway flow
  const startPaymentFlow = async () => {
    if (!selectedDoctorId || !selectedDate || !selectedSlot) return;

    setIsProcessingPayment(true);
    setPaymentError('');

    try {
      // 1. Create Order on our full-stack server
      const response = await fetch('/api/razorpay/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: totalAmount, currency: 'INR' })
      });

      if (!response.ok) {
        throw new Error('Failed to communicate with full-stack payment server.');
      }

      const data = await response.json();

      if (data.isTestMode) {
        // 2a. Server is in test mode (no credentials configured). Show realistic Razorpay checkout simulator.
        setTimeout(() => {
          setIsProcessingPayment(false);
          setShowMockRazorpayModal(true);
        }, 800);
      } else {
        // 2b. Server returned real order details. Trigger actual Razorpay SDK checkout!
        setIsProcessingPayment(false);
        const options = {
          key: data.keyId,
          amount: data.amount,
          currency: data.currency,
          name: 'CareLoop Health',
          description: `Consultation with ${selectedDoctor?.name}`,
          order_id: data.orderId,
          handler: function (paymentResponse: any) {
            // Success handler from Razorpay
            handleFinalizeBooking(paymentResponse.razorpay_payment_id || 'pay_real_' + Math.random().toString(36).substring(2, 10));
          },
          prefill: {
            name: 'Patient User',
            email: 'patient@careloop.io',
            contact: '9999999999'
          },
          theme: {
            color: '#0d9488' // matches our teal branding
          },
          modal: {
            ondismiss: function () {
              setIsProcessingPayment(false);
              setPaymentError('Payment cancelled by patient.');
            }
          }
        };

        const RazorpayInstance = new (window as any).Razorpay(options);
        RazorpayInstance.open();
      }

    } catch (err: any) {
      console.error(err);
      setPaymentError(err.message || 'Payment gateway connection error. Please try again.');
      setIsProcessingPayment(false);
    }
  };

  const resetBooking = () => {
    setSelectedDoctorId(null);
    setShowConfirmation(false);
    setLastBookedAppt(null);
    setShowPaymentReview(false);
    setPaymentError('');
  };

  // Render Confirmation view
  if (showConfirmation && lastBookedAppt) {
    return (
      <div className="max-w-xl mx-auto sleek-card p-8 text-center animate-fade-in" id="booking-confirmation">
        <div className="w-16 h-16 bg-brand-primary-light rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 className="w-10 h-10 text-brand-primary animate-bounce-slow" />
        </div>
        <h2 className="text-2xl font-bold text-brand-text-dark tracking-tight mb-2">Appointment Secured!</h2>
        <p className="text-brand-text-muted mb-6 text-sm">
          Your booking with <span className="font-semibold text-slate-700">{lastBookedAppt.doctorName}</span> has been paid and confirmed.
        </p>

        <div className="bg-slate-50/80 border border-brand-border rounded-2xl p-6 text-left mb-8 space-y-4">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-teal-100/80 rounded-xl flex items-center justify-center">
              <User className="w-5 h-5 text-brand-primary" />
            </div>
            <div>
              <div className="text-[10px] text-brand-text-muted font-bold tracking-wider uppercase">PROVIDER</div>
              <div className="text-sm font-bold text-brand-text-dark">{lastBookedAppt.doctorName}</div>
              <div className="text-xs text-brand-text-muted">{lastBookedAppt.specialty}</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 border-t border-brand-border pt-4">
            <div className="flex items-center gap-3">
              <Calendar className="w-5 h-5 text-brand-text-muted" />
              <div>
                <div className="text-[10px] text-brand-text-muted font-bold tracking-wider uppercase">DATE</div>
                <div className="text-xs font-semibold text-brand-text-dark">{lastBookedAppt.date}</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Clock className="w-5 h-5 text-brand-text-muted" />
              <div>
                <div className="text-[10px] text-brand-text-muted font-bold tracking-wider uppercase">TIME SLOT</div>
                <div className="text-xs font-semibold text-brand-text-dark">{lastBookedAppt.slot}</div>
              </div>
            </div>
          </div>

          <div className="border-t border-brand-border pt-4 space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="text-brand-text-muted font-medium">Transaction Amount Paid:</span>
              <span className="font-bold text-emerald-600 font-mono">₹{lastBookedAppt.amountPaid}.00</span>
            </div>
            <div className="flex justify-between items-center text-[10px] font-mono text-slate-400">
              <span>Razorpay ID:</span>
              <span className="font-semibold">{lastBookedAppt.paymentId}</span>
            </div>
          </div>
        </div>

        <button
          onClick={resetBooking}
          className="w-full sleek-button"
          id="btn-book-another"
        >
          Book Another Appointment
        </button>
      </div>
    );
  }

  // Render Payment / Billing Review overlay
  if (showPaymentReview && selectedDoctor) {
    return (
      <div className="max-w-xl mx-auto space-y-6 animate-fade-in" id="billing-payment-review">
        
        {/* Back navigation */}
        <button
          onClick={() => setShowPaymentReview(false)}
          className="flex items-center gap-1.5 text-xs text-brand-text-muted hover:text-brand-primary font-bold cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          Change date/time slot
        </button>

        <div className="sleek-card p-6 md:p-8 space-y-6">
          <div className="border-b border-brand-border pb-4">
            <h2 className="text-xl font-bold text-brand-text-dark tracking-tight">Review Consultation Booking</h2>
            <p className="text-xs text-brand-text-muted">Review patient slot and proceed to secure Razorpay checkout</p>
          </div>

          {/* Consultation info card */}
          <div className="p-4 bg-slate-50/80 border border-brand-border rounded-2xl space-y-4">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 bg-teal-100 rounded-2xl flex items-center justify-center text-brand-primary font-bold text-sm">
                {selectedDoctor.name.split(' ').slice(1).map(n => n[0]).join('')}
              </div>
              <div>
                <h3 className="text-sm font-bold text-brand-text-dark">{selectedDoctor.name}</h3>
                <p className="text-xs text-brand-primary font-semibold">{selectedDoctor.specialty}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 border-t border-slate-200/50 pt-3.5 text-xs">
              <div>
                <span className="block text-[10px] font-bold text-brand-text-muted uppercase tracking-wider">APPOINTMENT DATE</span>
                <span className="font-bold text-brand-text-dark">{selectedDate}</span>
              </div>
              <div>
                <span className="block text-[10px] font-bold text-brand-text-muted uppercase tracking-wider">TIME SLOT</span>
                <span className="font-bold text-brand-text-dark">{selectedSlot}</span>
              </div>
            </div>
          </div>

          {/* Billing breakdown */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-brand-text-muted uppercase tracking-wider">Fee Statement</h4>
            
            <div className="space-y-2 text-xs font-semibold">
              <div className="flex justify-between items-center text-brand-text-dark">
                <span>Doctor Consultation Fee</span>
                <span className="font-mono">₹{consultationFee}.00</span>
              </div>
              <div className="flex justify-between items-center text-brand-text-muted">
                <span>GST (18%)</span>
                <span className="font-mono">₹{gst}.00</span>
              </div>
              <div className="flex justify-between items-center text-brand-text-dark border-t border-brand-border pt-3.5 text-sm">
                <span>Total Payable Amount</span>
                <span className="font-bold text-teal-600 font-mono">₹{totalAmount}.00</span>
              </div>
            </div>
          </div>

          {/* Error notice if payment failed */}
          {paymentError && (
            <div className="p-4 bg-rose-50 border border-rose-150 rounded-xl flex items-start gap-2.5 text-xs text-rose-700">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <div><strong>Payment Failed:</strong> {paymentError}</div>
            </div>
          )}

          {/* Submit Action */}
          <div className="space-y-3 pt-2">
            {isProcessingPayment ? (
              <button
                disabled
                className="w-full py-3.5 bg-slate-100 border border-slate-200 text-slate-400 rounded-2xl font-bold text-xs flex items-center justify-center gap-2"
              >
                <Loader2 className="w-4 h-4 animate-spin text-slate-400" />
                Initializing Secured Razorpay Gateway...
              </button>
            ) : (
              <button
                onClick={startPaymentFlow}
                className="w-full sleek-button flex items-center justify-center gap-2 text-sm"
                id="btn-razorpay-checkout"
              >
                <CreditCard className="w-4 h-4" />
                Pay ₹{totalAmount} via Razorpay
              </button>
            )}

            <div className="flex items-center justify-center gap-1.5 text-[10px] text-brand-text-muted leading-none">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Razorpay Secure Standard PCI-DSS Compliant Encryption</span>
            </div>
          </div>

        </div>

        {/* Realistic Interactive Razorpay Sandbox Simulator Modal */}
        {showMockRazorpayModal && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-[999]" id="razorpay-mock-modal">
            <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden shadow-2xl border border-slate-200 animate-scale-up">
              
              {/* Razorpay signature header */}
              <div className="bg-[#0b1a3f] p-4 text-white flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 bg-teal-500 rounded-lg flex items-center justify-center font-bold text-white text-[10px]">
                    CL
                  </div>
                  <div>
                    <h4 className="text-xs font-bold leading-tight">CareLoop Patient Portal</h4>
                    <span className="text-[9px] text-slate-300">Amount: ₹{totalAmount}.00</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-black tracking-widest text-[#2f75f7]">Razorpay</span>
                  <p className="text-[8px] text-slate-400 font-mono">SANDBOX ACTIVE</p>
                </div>
              </div>

              {/* Sandbox guidance info */}
              <div className="p-5 bg-slate-50 border-b border-brand-border space-y-2">
                <div className="flex gap-2 text-xs text-amber-800">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-amber-600" />
                  <div>
                    <p className="font-bold">Keys Not Configured (Expected in Preview)</p>
                    <p className="text-[11px] text-amber-700/90 leading-normal">
                      This high-fidelity simulator lets you mock transaction events locally. To run live transactions, define your <code className="bg-slate-200/80 px-1 rounded text-red-600 font-bold">RAZORPAY_KEY_ID</code> and secret in the Secrets panel in AI Studio.
                    </p>
                  </div>
                </div>
              </div>

              {/* Payment selection simulation */}
              <div className="p-5 space-y-4">
                <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">Select Demo Payment Method</p>
                
                <div className="space-y-2">
                  <button
                    onClick={() => handleFinalizeBooking('pay_mock_' + Math.random().toString(36).substring(2, 10))}
                    className="w-full p-3 border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-xl text-left text-xs font-bold flex items-center justify-between transition-colors cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      Simulate SUCCESSFUL Payment
                    </span>
                    <span className="text-[10px] text-emerald-600 font-mono">₹{totalAmount}</span>
                  </button>

                  <button
                    onClick={() => {
                      setShowMockRazorpayModal(false);
                      setPaymentError('Simulated transaction rejected/cancelled.');
                    }}
                    className="w-full p-3 border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-800 rounded-xl text-left text-xs font-bold flex items-center justify-between transition-colors cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-rose-600" />
                      Simulate DECLINED/CANCELLED Payment
                    </span>
                    <span className="text-[10px] text-rose-600">Fail</span>
                  </button>
                </div>
              </div>

              {/* Modal footer */}
              <div className="p-3 bg-slate-50 text-center border-t border-brand-border">
                <button
                  onClick={() => {
                    setShowMockRazorpayModal(false);
                    setPaymentError('Dismissed transaction gateway.');
                  }}
                  className="text-xs text-brand-text-muted hover:text-slate-800 font-bold cursor-pointer"
                >
                  Close Gate
                </button>
              </div>

            </div>
          </div>
        )}

      </div>
    );
  }

  // Render Doctor selection and slot choosing view (standard Patient view)
  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-fade-in" id="appointment-booking-view">
      {/* Doctor Selection List */}
      <div className="lg:col-span-7 space-y-4">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-lg font-bold text-brand-text-dark tracking-tight">Available Healthcare Providers</h2>
          <span className="text-xs text-brand-text-muted font-mono">Select a practitioner to start</span>
        </div>

        <div className="space-y-4">
          {doctors.map((doctor) => {
            const isSelected = doctor.id === selectedDoctorId;
            return (
              <div
                key={doctor.id}
                id={`doctor-card-${doctor.id}`}
                onClick={() => {
                  setSelectedDoctorId(doctor.id);
                  setSelectedSlot(null);
                  setTimeout(() => {
                    const el = document.getElementById('booking-slots-config');
                    if (el) {
                      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    }
                  }, 100);
                }}
                className={`group cursor-pointer transition-all p-5 ${
                  isSelected
                    ? 'sleek-card border-brand-primary ring-2 ring-brand-primary-light shadow-md'
                    : 'sleek-card hover:border-slate-350 hover:shadow-sm'
                }`}
              >
                <div className="flex items-start gap-4">
                  {/* Doctor Avatar Placeholder */}
                  <div className="relative w-14 h-14 bg-gradient-to-br from-blue-50 to-teal-100 rounded-2xl flex items-center justify-center text-brand-primary font-bold text-lg border border-slate-50 shrink-0">
                    {doctor.name.split(' ').slice(1).map(n => n[0]).join('')}
                    <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-brand-primary rounded-full border-2 border-white flex items-center justify-center">
                      <Award className="w-3 h-3 text-white" />
                    </div>
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-bold text-brand-text-dark text-sm group-hover:text-brand-primary transition-colors">
                        {doctor.name}
                      </h3>
                      <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-50 text-amber-700 border border-amber-100">
                        <Star className="w-2.5 h-2.5 fill-amber-500 text-amber-500" />
                        {doctor.rating}
                      </span>
                    </div>

                    <p className="text-xs font-semibold text-brand-primary mb-2">{doctor.specialty}</p>

                    <div className="flex flex-wrap gap-x-4 gap-y-1.5 text-xs text-brand-text-muted">
                      <div className="flex items-center gap-1">
                        <Award className="w-3.5 h-3.5 text-slate-400" />
                        <span>{doctor.experience} experience</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-slate-400" />
                        <span className="truncate max-w-[200px]">{doctor.hospital}</span>
                      </div>
                    </div>

                    {/* Active Emergency Notice */}
                    {surgeryTimings?.[doctor.id]?.isEmergencyActive && (
                      <div className="mt-2.5 p-2.5 bg-rose-50 border border-rose-100 rounded-xl text-[10px] text-rose-800 flex items-start gap-1.5 text-left animate-pulse">
                        <span className="shrink-0 text-xs">🚨</span>
                        <div>
                          <strong className="font-extrabold uppercase text-rose-600 block">Emergency Surgery active</strong>
                          <span className="text-rose-700 font-medium leading-relaxed block mt-0.5">
                            Estimated: {surgeryTimings[doctor.id].startTime} - {surgeryTimings[doctor.id].endTime}. Appointments during these hours will experience delays.
                          </span>
                        </div>
                      </div>
                    )}

                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-brand-border flex items-center justify-between">
                  <div className="text-xs text-brand-text-muted">
                    Availability:{' '}
                    <span className="font-semibold text-brand-text-dark">
                      {doctor.availableDays.join(', ')}
                    </span>
                  </div>
                  <span className="text-xs font-bold text-brand-primary group-hover:underline flex items-center gap-1">
                    Book Appointment &rarr;
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Date & Time Slot Picker */}
      <div className="lg:col-span-5" id="booking-slots-config">
        <div className="sleek-card sticky top-24 shadow-sm p-6">
          <h3 className="font-bold text-brand-text-dark text-base mb-4 tracking-tight">Configure Booking</h3>

          {selectedDoctor ? (
            <div className="space-y-6">
              {/* Selected Doctor Summary */}
              <div className="p-4 bg-slate-50/80 border border-brand-border rounded-2xl flex items-center gap-3">
                <div className="w-10 h-10 bg-brand-primary-light rounded-xl flex items-center justify-center text-brand-primary font-bold text-xs">
                  {selectedDoctor.name.split(' ').slice(1).map(n => n[0]).join('')}
                </div>
                <div>
                  <div className="text-xs font-bold text-brand-text-dark">{selectedDoctor.name}</div>
                  <div className="text-[10px] text-brand-primary font-semibold">{selectedDoctor.specialty}</div>
                </div>
              </div>

              {/* Slot picker emergency warning */}
              {surgeryTimings?.[selectedDoctor.id]?.isEmergencyActive && (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-2xl text-xs text-amber-850 text-left space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-amber-900">
                    <span className="text-sm">⚠️</span>
                    <span>Provider Emergency Delay Alert</span>
                  </div>
                  <p className="text-[11px] text-amber-800 leading-relaxed font-semibold">
                    {selectedDoctor.name} is currently in an unscheduled emergency surgery today from <span className="underline font-mono">{surgeryTimings[selectedDoctor.id].startTime}</span> to <span className="underline font-mono">{surgeryTimings[selectedDoctor.id].endTime}</span>.
                  </p>
                  <p className="text-[10px] text-amber-700 leading-normal italic">
                    Appointments booked during these hours will be subject to delays or rescheduled. Thank you for your support.
                  </p>
                </div>
              )}

              {/* Date Input */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-brand-text-muted tracking-wider uppercase">
                  Select Date
                </label>
                <div className="relative">
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => {
                      setSelectedDate(e.target.value);
                      setSelectedSlot(null);
                    }}
                    min="2026-07-05"
                    max="2026-07-31"
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 hover:bg-slate-100 border border-brand-border rounded-2xl text-brand-text-dark text-sm focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary transition-all cursor-pointer font-bold"
                  />
                  <Calendar className="w-4 h-4 text-brand-text-muted absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>

                {selectedDate && (
                  <div className="text-[11px] font-medium mt-1">
                    {isDayAvailable ? (
                      <span className="text-emerald-600 flex items-center gap-1">
                        ● Available ({getDayOfWeekName(selectedDate)})
                      </span>
                    ) : (
                      <span className="text-rose-600 flex items-center gap-1">
                        ▲ {selectedDoctor.name} is not available on {getDayOfWeekName(selectedDate)}s
                      </span>
                    )}
                  </div>
                )}
              </div>

              {/* Time Slots Picker */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-brand-text-muted tracking-wider uppercase">
                  Select Time Slot
                </label>

                {isDayAvailable ? (
                  <div className="grid grid-cols-2 gap-2">
                    {selectedDoctor.availableSlots.map((slot) => {
                      const booked = isSlotBooked(slot);
                      const isSlotSelected = selectedSlot === slot;

                      return (
                        <button
                          key={slot}
                          disabled={booked}
                          id={`slot-btn-${slot.replace(' ', '-').toLowerCase()}`}
                          onClick={() => setSelectedSlot(slot)}
                          className={`py-2.5 px-3 text-xs font-bold rounded-xl border transition-all flex items-center justify-center gap-1.5 ${
                            booked
                              ? 'bg-slate-100 border-slate-100 text-slate-400 cursor-not-allowed line-through'
                              : isSlotSelected
                              ? 'bg-brand-primary border-brand-primary text-white shadow-sm'
                              : 'bg-white border-brand-border hover:border-slate-350 text-brand-text-dark hover:bg-slate-50'
                          }`}
                        >
                          <Clock className="w-3.5 h-3.5" />
                          {slot}
                          {booked && <span className="text-[9px] text-slate-450">(Booked)</span>}
                        </button>
                      );
                    })}
                  </div>
                ) : (
                  <div className="p-4 bg-slate-50 rounded-2xl border border-dashed border-slate-200 text-center text-xs text-brand-text-muted font-semibold">
                    Please select a date on which the doctor is available: <br />
                    <span className="font-bold text-brand-text-dark text-[11px]">
                      {selectedDoctor.availableDays.join(', ')}
                    </span>
                  </div>
                )}
              </div>

              {/* Action Button */}
              <button
                onClick={() => setShowPaymentReview(true)}
                disabled={!selectedDate || !selectedSlot || !isDayAvailable}
                className="w-full sleek-button disabled:bg-slate-200 disabled:text-slate-400 disabled:cursor-not-allowed mt-4 cursor-pointer"
                id="btn-confirm-appointment"
              >
                Proceed to Checkout (₹{totalAmount})
              </button>
            </div>
          ) : (
            <div className="py-12 text-center text-brand-text-muted text-sm font-semibold">
              <Calendar className="w-10 h-10 text-slate-200 mx-auto mb-3" />
              <p>Select a medical professional to proceed with booking details.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
