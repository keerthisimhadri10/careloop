import React, { useState } from 'react';
import { Doctor, Appointment, Visit, SymptomCheckIn } from '../types';
import { 
  User, Calendar, Clock, Activity, FileText, CheckCircle2, 
  Sparkles, AlertCircle, Heart, PlusCircle, CheckSquare, RefreshCw,
  AlertTriangle, Play, HelpCircle
} from 'lucide-react';

interface DoctorDashboardProps {
  doctors: Doctor[];
  appointments: Appointment[];
  visits: Visit[];
  checkIns: SymptomCheckIn[];
  onAddVisit: (visit: Visit) => void;
  surgeryTimings?: Record<string, {
    isEmergencyActive: boolean;
    startTime: string;
    endTime: string;
    note: string;
  }>;
  onUpdateSurgeryTiming?: (doctorId: string, timing: {
    isEmergencyActive: boolean;
    startTime: string;
    endTime: string;
    note: string;
  }) => void;
}

export default function DoctorDashboard({
  doctors,
  appointments,
  visits,
  checkIns,
  onAddVisit,
  surgeryTimings,
  onUpdateSurgeryTiming,
}: DoctorDashboardProps) {
  // Currently logged-in/selected Doctor profile
  const [activeDoctorId, setActiveDoctorId] = useState<string>(doctors[0]?.id || 'doc-1');
  const activeDoctor = doctors.find(d => d.id === activeDoctorId) || doctors[0];

  // Live Clock State
  const [currentTime, setCurrentTime] = React.useState<Date>(new Date());
  React.useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Surgery Configuration States
  const activeSurgeryTiming = (surgeryTimings && surgeryTimings[activeDoctorId]) || {
    isEmergencyActive: false,
    startTime: '11:00 AM',
    endTime: '02:00 PM',
    note: 'Emergency Surgery in progress. Clinic consultations will resume shortly.'
  };

  const [inputStartTime, setInputStartTime] = useState<string>(activeSurgeryTiming.startTime);
  const [inputEndTime, setInputEndTime] = useState<string>(activeSurgeryTiming.endTime);
  const [inputNote, setInputNote] = useState<string>(activeSurgeryTiming.note);

  // Sync inputs when active doctor or surgeryTimings prop changes
  React.useEffect(() => {
    setInputStartTime(activeSurgeryTiming.startTime);
    setInputEndTime(activeSurgeryTiming.endTime);
    setInputNote(activeSurgeryTiming.note);
  }, [activeDoctorId, surgeryTimings]);

  const handleToggleEmergency = (active: boolean) => {
    if (onUpdateSurgeryTiming) {
      onUpdateSurgeryTiming(activeDoctorId, {
        isEmergencyActive: active,
        startTime: inputStartTime,
        endTime: inputEndTime,
        note: inputNote,
      });
    }
  };

  const handleSaveSurgeryDetails = (e: React.FormEvent) => {
    e.preventDefault();
    if (onUpdateSurgeryTiming) {
      onUpdateSurgeryTiming(activeDoctorId, {
        isEmergencyActive: activeSurgeryTiming.isEmergencyActive,
        startTime: inputStartTime,
        endTime: inputEndTime,
        note: inputNote,
      });
      alert(`Surgery timings updated for ${activeDoctor.name}! Real-time alerts have been dispatched to patients.`);
    }
  };

  const setQuickSurgeryWindow = (hours: number) => {
    const start = new Date();
    const end = new Date();
    end.setHours(start.getHours() + hours);

    const formatTime = (d: Date) => {
      return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    };

    const newStart = formatTime(start);
    const newEnd = formatTime(end);

    setInputStartTime(newStart);
    setInputEndTime(newEnd);

    if (onUpdateSurgeryTiming) {
      onUpdateSurgeryTiming(activeDoctorId, {
        isEmergencyActive: true,
        startTime: newStart,
        endTime: newEnd,
        note: inputNote || 'Emergency Surgery in progress.',
      });
    }
  };

  // Consultation Form State
  const [showConsultForm, setShowConsultForm] = useState<boolean>(false);
  const [selectedApptId, setSelectedApptId] = useState<string>('custom');
  
  const [formPatientName, setFormPatientName] = useState<string>('Default Patient');
  const [formDiagnosis, setFormDiagnosis] = useState<string>('');
  const [formRawNotes, setFormRawNotes] = useState<string>('');
  const [formFollowUpDate, setFormFollowUpDate] = useState<string>('');
  
  // AI Simplification states
  const [isLoadingAI, setIsLoadingAI] = useState<boolean>(false);
  const [loadingStep, setLoadingStep] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [aiResult, setAiResult] = useState<{
    simplifiedText: string;
    medications: Array<{
      name: string;
      dosage: string;
      frequency: string;
      duration: string;
      slots: ('morning' | 'afternoon' | 'evening')[];
    }>;
    suggestedFollowUpDays: number;
  } | null>(null);

  // Filter appointments for the active doctor
  const doctorAppointments = appointments.filter(appt => appt.doctorId === activeDoctorId);
  const upcomingAppts = doctorAppointments.filter(appt => appt.status === 'upcoming');
  const completedAppts = doctorAppointments.filter(appt => appt.status === 'completed');

  // Load clinical note templates for quick doctor testing
  const loadTemplate = (type: 'strep' | 'bronchitis' | 'rash') => {
    if (type === 'strep') {
      setFormDiagnosis('Streptococcal Pharyngitis');
      setFormRawNotes(
        'Severe sore throat, temp 101.5 F, swollen glands. Rapid test (+).\n\n' +
        'Rx: Amoxicillin 500mg po bid x 10 days\n' +
        'Rx: Ibuprofen 400mg po q4-6h prn throat pain x 5 days\n\n' +
        'saltwater gargles, rest, high hydration. F/u in 3 days if fever persists.'
      );
    } else if (type === 'bronchitis') {
      setFormDiagnosis('Acute Bronchitis');
      setFormRawNotes(
        'Productive cough x 4 days, mild wheezing, lungs clear but coarse. No fever.\n\n' +
        'Rx: Albuterol inhaler 90mcg 1-2 puffs q4h prn cough x 7 days\n' +
        'Rx: Dextromethorphan syrup 10ml po q6h x 5 days\n\n' +
        'increase humidity, plenty of fluids, avoid smoke.'
      );
    } else if (type === 'rash') {
      setFormDiagnosis('Allergic Contact Dermatitis');
      setFormRawNotes(
        'Erythematous rash, vesicular lesions with pruritus on left wrist. Appears consistent with metal jewelry exposure.\n\n' +
        'Rx: Triamcinolone 0.1% topical ointment apply thin layer bid x 7 days\n' +
        'Rx: Loratadine 10mg po qd x 10 days for itching\n\n' +
        'discontinue wearing metal watch. f/u in 7 days if not improved.'
      );
    }
  };

  const handleApptLinkChange = (apptId: string) => {
    setSelectedApptId(apptId);
    if (apptId === 'custom') {
      setFormPatientName('Default Patient');
    } else {
      const appt = appointments.find(a => a.id === apptId);
      if (appt) {
        setFormPatientName('Default Patient'); // The user is the standard mock patient
      }
    }
  };

  const handleConsultSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formDiagnosis.trim() || !formRawNotes.trim()) {
      setErrorMsg('Please enter a diagnosis and clinical shorthand notes.');
      return;
    }

    setErrorMsg('');
    setIsLoadingAI(true);
    setLoadingStep('Reviewing clinical notes and translating abbreviations...');

    try {
      const response = await fetch('/api/simplify-notes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ notes: formRawNotes }),
      });

      if (!response.ok) {
        throw new Error('Server returned an error while processing AI simplification.');
      }

      setLoadingStep('Mapping prescriptions to morning, afternoon, and evening slots...');
      const data = await response.json();

      setLoadingStep('Finalizing prescription schedule...');
      
      let finalFollowUpDate = formFollowUpDate;
      if (!finalFollowUpDate && data.suggestedFollowUpDays > 0) {
        const today = new Date('2026-07-05');
        today.setDate(today.getDate() + data.suggestedFollowUpDays);
        finalFollowUpDate = today.toISOString().split('T')[0];
      }

      const newVisit: Visit = {
        id: 'visit-' + Math.random().toString(36).substring(2, 9),
        doctorId: activeDoctorId,
        doctorName: activeDoctor.name,
        specialty: activeDoctor.specialty,
        date: '2026-07-05', // Consultation day is today
        diagnosis: formDiagnosis,
        rawNotes: formRawNotes,
        simplifiedNotes: data.simplifiedText,
        medications: data.medications,
        followUpDate: finalFollowUpDate || undefined,
      };

      onAddVisit(newVisit);

      // Reset Form State
      setShowConsultForm(false);
      setFormDiagnosis('');
      setFormRawNotes('');
      setFormFollowUpDate('');
      setSelectedApptId('custom');
      setAiResult(null);
      alert(`Consultation successfully logged for ${formPatientName}! AI simplified notes and medication checklists have been successfully generated and published to the Patient Portal.`);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Verification error connecting to Gemini. Please try again.');
    } finally {
      setIsLoadingAI(false);
    }
  };

  // Quick statistics
  const currentCheckIn = checkIns[0];

  return (
    <div className="space-y-8 animate-fade-in" id="doctor-dashboard">
      
      {/* Top Banner & Profile Switcher */}
      <div className="bg-gradient-to-br from-brand-primary to-emerald-800 rounded-[24px] p-6 text-white shadow-lg shadow-brand-primary/10 border border-brand-primary/20 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-extrabold px-3 py-1 rounded-full uppercase tracking-wider">
              Clinical Workstation
            </span>
            <span className="bg-white/10 text-slate-100 border border-white/10 text-[10px] font-medium px-2 py-0.5 rounded-full">
              ID: {activeDoctorId}
            </span>
          </div>
          <h2 className="text-2xl font-bold tracking-tight">
            Welcome, {activeDoctor.name}
          </h2>
          <p className="text-sm text-slate-200 font-medium">
            Manage consultations, prescribe medication, and review real-time patient wellness diagnostics.
          </p>
        </div>

        {/* Doctor Profile Dropdown Switcher */}
        <div className="bg-white/10 border border-white/10 rounded-2xl p-4 space-y-1.5 shrink-0">
          <label className="block text-[10px] font-extrabold text-slate-200 tracking-wider uppercase">
            Switch Doctor Profile
          </label>
          <select
            value={activeDoctorId}
            onChange={(e) => {
              setActiveDoctorId(e.target.value);
              setShowConsultForm(false);
            }}
            className="w-full bg-slate-900/60 text-white font-semibold text-xs border border-white/20 rounded-xl px-3.5 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-400"
          >
            {doctors.map((doc) => (
              <option key={doc.id} value={doc.id} className="text-slate-800">
                {doc.name} ({doc.specialty})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Column Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Appointments & Log Visit Form */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Section Header */}
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-bold text-brand-text-dark tracking-tight">Consultation Appointments</h3>
              <p className="text-xs text-brand-text-muted">Review and complete bookings scheduled by patients</p>
            </div>
            {!showConsultForm && (
              <button
                onClick={() => setShowConsultForm(true)}
                className="sleek-button flex items-center gap-1 text-xs"
                id="btn-doc-new-consult"
              >
                <PlusCircle className="w-4 h-4" />
                Log Custom Consult
              </button>
            )}
          </div>

          {/* AI Consultation Form */}
          {showConsultForm && (
            <form onSubmit={handleConsultSubmit} className="sleek-card border-emerald-600/20 bg-emerald-50/5 p-6 space-y-6" id="doc-consult-form">
              <div className="flex items-center justify-between border-b border-brand-border pb-4 mb-2">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-emerald-600 animate-pulse" />
                  <div>
                    <h4 className="font-bold text-brand-text-dark text-base">New Patient Consultation & AI RX</h4>
                    <p className="text-[10px] text-brand-text-muted">Enter findings. Gemini translates medical shorthand po/bid/qd dynamically.</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowConsultForm(false)}
                  className="text-xs text-brand-text-muted hover:text-rose-500 font-bold"
                >
                  Cancel
                </button>
              </div>

              {/* Linking Scheduled Appointments */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-brand-text-muted uppercase tracking-wider">
                    Link Scheduled Slot
                  </label>
                  <select
                    value={selectedApptId}
                    onChange={(e) => handleApptLinkChange(e.target.value)}
                    className="w-full px-4 py-2.5 bg-white border border-brand-border rounded-xl text-xs text-brand-text-dark font-semibold focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary"
                  >
                    <option value="custom">-- Independent Patient Visit (No Link) --</option>
                    {upcomingAppts.map((appt) => (
                      <option key={appt.id} value={appt.id}>
                        {appt.date} at {appt.slot} - Patient
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-brand-text-muted uppercase tracking-wider">
                    Patient Name
                  </label>
                  <input
                    type="text"
                    required
                    value={formPatientName}
                    disabled={selectedApptId !== 'custom'}
                    onChange={(e) => setFormPatientName(e.target.value)}
                    placeholder="e.g. John Doe"
                    className="w-full px-4 py-2.5 bg-white disabled:bg-slate-100 border border-brand-border rounded-xl text-xs text-brand-text-dark font-semibold focus:outline-none focus:ring-2 focus:ring-brand-primary/20"
                  />
                </div>
              </div>

              {/* Template quick-loaders */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-brand-text-muted uppercase tracking-wider">
                  Need quick prescription shorthand templates?
                </label>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => loadTemplate('strep')}
                    className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg text-[11px] font-bold border border-blue-100 transition-all cursor-pointer"
                  >
                    Load Strep Throat
                  </button>
                  <button
                    type="button"
                    onClick={() => loadTemplate('bronchitis')}
                    className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg text-[11px] font-bold border border-amber-100 transition-all cursor-pointer"
                  >
                    Load Bronchitis
                  </button>
                  <button
                    type="button"
                    onClick={() => loadTemplate('rash')}
                    className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg text-[11px] font-bold border border-emerald-100 transition-all cursor-pointer"
                  >
                    Load Contact Allergy
                  </button>
                </div>
              </div>

              {/* Diagnosis Field */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-brand-text-muted uppercase tracking-wider">
                  Diagnosis / Clinical Impression
                </label>
                <input
                  type="text"
                  required
                  value={formDiagnosis}
                  onChange={(e) => setFormDiagnosis(e.target.value)}
                  placeholder="e.g. Acute Pharyngitis, Lumbar Strain"
                  className="w-full px-4 py-2.5 bg-white border border-brand-border rounded-xl text-xs text-brand-text-dark font-semibold focus:outline-none"
                />
              </div>

              {/* Clinical notes and shorthand */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-brand-text-muted uppercase tracking-wider">
                    Raw Shorthand Notes & Prescriptions
                  </label>
                  <span className="text-[10px] text-emerald-600 font-bold flex items-center gap-1">
                    <Sparkles className="w-3 h-3 animate-pulse" />
                    AI simplifies abbreviations (bid, po, qd)
                  </span>
                </div>
                <textarea
                  required
                  value={formRawNotes}
                  onChange={(e) => setFormRawNotes(e.target.value)}
                  rows={6}
                  placeholder="e.g. Rx: Amoxicillin 500mg po bid x 10d. gargle salt water. f/u in 3 days if fever persists."
                  className="w-full px-4 py-3 bg-white border border-brand-border rounded-2xl text-xs text-brand-text-dark focus:outline-none focus:ring-2 focus:ring-brand-primary/20 font-mono leading-relaxed"
                ></textarea>
              </div>

              {/* Follow up Date manually */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-brand-text-muted uppercase tracking-wider">
                  Manually Set Follow-up Date (Optional)
                </label>
                <input
                  type="date"
                  value={formFollowUpDate}
                  min="2026-07-05"
                  onChange={(e) => setFormFollowUpDate(e.target.value)}
                  className="max-w-xs block px-4 py-2.5 bg-white border border-brand-border rounded-xl text-xs text-brand-text-dark font-semibold focus:outline-none"
                />
                <span className="text-[10px] text-brand-text-muted block">
                  If left blank, Gemini will parse the notes and calculate the recommended period in days automatically.
                </span>
              </div>

              {/* Error messages */}
              {errorMsg && (
                <div className="p-4 bg-rose-50 border border-rose-150 rounded-xl flex items-start gap-2 text-xs font-semibold text-rose-700">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <div><strong>AI Error:</strong> {errorMsg}</div>
                </div>
              )}

              {/* Actions submit with AI Loading */}
              {isLoadingAI ? (
                <div className="bg-emerald-50 border border-emerald-100 rounded-2xl p-5 text-center flex flex-col items-center justify-center space-y-3">
                  <RefreshCw className="w-8 h-8 text-emerald-600 animate-spin" />
                  <div className="text-xs font-bold text-emerald-800 tracking-wide animate-pulse">
                    {loadingStep}
                  </div>
                  <div className="text-[10px] text-brand-text-muted">
                    Contacting Gemini 3.5. Translating Latin dosing shorthand into patient safety schedules...
                  </div>
                </div>
              ) : (
                <button
                  type="submit"
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
                >
                  <Sparkles className="w-4 h-4" />
                  AI Analyze & Publish Consultation
                </button>
              )}
            </form>
          )}

          {/* Appointments list */}
          <div className="space-y-4">
            {upcomingAppts.length === 0 ? (
              <div className="sleek-card p-12 text-center">
                <Calendar className="w-12 h-12 text-slate-200 mx-auto mb-3" />
                <p className="font-bold text-brand-text-dark">No upcoming appointments</p>
                <p className="text-xs text-brand-text-muted mt-1">
                  When a patient books a slot and completes their Razorpay payment, it will instantly appear in this queue.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {upcomingAppts.map((appt) => (
                  <div
                    key={appt.id}
                    className="sleek-card hover:shadow-md transition-all border-l-4 border-l-brand-primary p-5 flex flex-col md:flex-row md:items-center justify-between gap-4"
                  >
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-mono font-bold text-brand-text-muted uppercase tracking-wider">
                          {appt.date} • {appt.slot}
                        </span>
                        {appt.paymentId && (
                          <span className="px-2.5 py-0.5 rounded-full text-[9px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-100 flex items-center gap-1">
                            <CheckSquare className="w-2.5 h-2.5" />
                            PAID ₹{appt.amountPaid || 590} VIA RAZORPAY
                          </span>
                        )}
                      </div>

                      <h4 className="font-bold text-brand-text-dark text-sm tracking-tight flex items-center gap-1.5">
                        <User className="w-4 h-4 text-slate-400" />
                        Patient (Mock Care Account)
                      </h4>

                      {appt.paymentId && (
                        <p className="text-[10px] text-slate-400 font-mono">
                          Receipt ID: <span className="font-semibold text-slate-500">{appt.paymentId}</span>
                        </p>
                      )}
                    </div>

                    <button
                      onClick={() => {
                        setShowConsultForm(true);
                        handleApptLinkChange(appt.id);
                        setFormDiagnosis('');
                        setFormRawNotes('');
                      }}
                      className="px-4 py-2 bg-brand-primary hover:bg-brand-hover text-white font-bold text-xs rounded-xl cursor-pointer shadow-sm shadow-brand-primary/10 transition-all self-start md:self-center"
                    >
                      Consult Patient
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Historic consults */}
          {completedAppts.length > 0 && (
            <div className="space-y-3 pt-4">
              <h4 className="text-xs font-bold text-brand-text-muted uppercase tracking-wider">
                Completed Consults Today ({completedAppts.length})
              </h4>
              <div className="space-y-2">
                {completedAppts.map((appt) => (
                  <div key={appt.id} className="p-3.5 bg-slate-50/80 border border-brand-border rounded-xl flex justify-between items-center text-xs">
                    <div>
                      <span className="font-bold text-brand-text-dark">Patient (Mock Account)</span>
                      <span className="text-slate-300 mx-2">|</span>
                      <span className="text-brand-text-muted">{appt.date} • {appt.slot}</span>
                    </div>
                    <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-lg">
                      Completed & Prescribed
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Right Column: Clock, Emergency Surgery, and Patient Symptom Trends */}
        <div className="lg:col-span-5 space-y-6">

          {/* Clinical Clock & Surgery Timings Panel */}
          <div className="sleek-card space-y-6 border border-rose-600/15" id="clinical-dispatcher">
            {/* Clock & Status */}
            <div className="flex items-center justify-between border-b border-brand-border pb-4">
              <div className="space-y-1 text-left">
                <span className="text-[10px] font-mono font-black text-rose-600 uppercase tracking-widest flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-rose-500 rounded-full animate-ping"></span>
                  Live Clinical Clock
                </span>
                <div className="font-mono text-2xl font-black text-slate-800 tracking-tight leading-none">
                  {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                </div>
                <div className="text-[9px] text-slate-400 font-medium">
                  {currentTime.toLocaleDateString([], { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric' })}
                </div>
              </div>

              {/* Status Badge */}
              <div className="text-right">
                {activeSurgeryTiming.isEmergencyActive ? (
                  <span className="px-2.5 py-1.5 rounded-full text-[10px] font-black bg-rose-50 text-rose-700 border border-rose-200 inline-flex items-center gap-1 animate-pulse">
                    <span className="w-2 h-2 bg-rose-600 rounded-full animate-ping"></span>
                    EMERGENCY SURGERY
                  </span>
                ) : (
                  <span className="px-2.5 py-1.5 rounded-full text-[10px] font-black bg-emerald-50 text-emerald-700 border border-emerald-200 inline-flex items-center gap-1">
                    <span className="w-2 h-2 bg-emerald-500 rounded-full"></span>
                    ACTIVE / IN CLINIC
                  </span>
                )}
              </div>
            </div>

            {/* Emergency Operations Center */}
            <div className="space-y-4">
              <div className="space-y-1 text-left">
                <h4 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-rose-500" />
                  Emergency Surgery Planner
                </h4>
                <p className="text-[11px] text-slate-500 leading-normal">
                  Toggle your status and set estimated surgery timings to delay your clinic availability and notify patients instantly.
                </p>
              </div>

              {/* Active Toggle Buttons */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => handleToggleEmergency(false)}
                  className={`py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
                    !activeSurgeryTiming.isEmergencyActive
                      ? 'bg-emerald-600 border-emerald-600 text-white shadow-sm'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <CheckSquare className="w-3.5 h-3.5" />
                  Consulting In Office
                </button>
                <button
                  type="button"
                  onClick={() => handleToggleEmergency(true)}
                  className={`py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
                    activeSurgeryTiming.isEmergencyActive
                      ? 'bg-rose-600 border-rose-600 text-white shadow-sm shadow-rose-250'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-rose-50'
                  }`}
                >
                  <AlertCircle className="w-3.5 h-3.5" />
                  Emergency Surgery
                </button>
              </div>

              {/* Timing inputs & Note */}
              <form onSubmit={handleSaveSurgeryDetails} className="space-y-4 bg-slate-50/70 p-4 rounded-2xl border border-brand-border">
                <div className="grid grid-cols-2 gap-3 text-left">
                  <div className="space-y-1.5">
                    <label className="block text-[9px] font-extrabold text-slate-500 tracking-wider uppercase">
                      Surgery Start
                    </label>
                    <input
                      type="text"
                      required
                      value={inputStartTime}
                      onChange={(e) => setInputStartTime(e.target.value)}
                      placeholder="e.g. 11:00 AM"
                      className="w-full px-3 py-2 bg-white border border-brand-border rounded-xl text-xs text-slate-850 font-bold focus:outline-none"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="block text-[9px] font-extrabold text-slate-500 tracking-wider uppercase">
                      Surgery End
                    </label>
                    <input
                      type="text"
                      required
                      value={inputEndTime}
                      onChange={(e) => setInputEndTime(e.target.value)}
                      placeholder="e.g. 02:00 PM"
                      className="w-full px-3 py-2 bg-white border border-brand-border rounded-xl text-xs text-slate-850 font-bold focus:outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-1.5 text-left">
                  <label className="block text-[9px] font-extrabold text-slate-500 tracking-wider uppercase">
                    Urgent Patient Notice
                  </label>
                  <textarea
                    rows={2}
                    value={inputNote}
                    onChange={(e) => setInputNote(e.target.value)}
                    placeholder="Provide a quick notice for patients..."
                    className="w-full px-3 py-2 bg-white border border-brand-border rounded-xl text-xs text-slate-850 focus:outline-none leading-relaxed resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2 px-3 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer"
                >
                  Save & Broadcast Timings
                </button>
              </form>

              {/* Quick Set buttons for Busy Doctors */}
              <div className="space-y-2 text-left">
                <span className="text-[9px] font-extrabold text-slate-400 uppercase tracking-wider block">
                  Quick Delay Dispatcher (One-Click)
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setQuickSurgeryWindow(2)}
                    className="py-1.5 px-2 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg text-[10px] font-bold border border-blue-100 transition-all cursor-pointer text-center"
                  >
                    ⚡ Surgery: Next 2 Hours
                  </button>
                  <button
                    type="button"
                    onClick={() => setQuickSurgeryWindow(3)}
                    className="py-1.5 px-2 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg text-[10px] font-bold border border-amber-100 transition-all cursor-pointer text-center"
                  >
                    ⚡ Surgery: Next 3 Hours
                  </button>
                </div>
              </div>

            </div>
          </div>

          <div className="sleek-card space-y-6 sticky top-24">
            
            <div>
              <div className="flex items-center gap-1.5 text-xs font-bold text-brand-primary uppercase tracking-wider mb-1">
                <Activity className="w-4 h-4 animate-pulse" />
                Live Patient Diagnostics
              </div>
              <h3 className="font-bold text-brand-text-dark text-base">Wellness Trend Tracker</h3>
              <p className="text-xs text-brand-text-muted">
                Pre-consultation review: evaluate patient wellness scores and logs submitted over the last 14 days
              </p>
            </div>

            {/* Quick Summary widget */}
            {currentCheckIn ? (
              <div className="p-4 bg-slate-50/80 border border-brand-border rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-bold text-brand-text-muted">
                    LAST LOGGED CHECK-IN ({currentCheckIn.date})
                  </span>
                  <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${
                    currentCheckIn.rating >= 4 
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' 
                      : currentCheckIn.rating === 3 
                      ? 'bg-amber-50 text-amber-700 border border-amber-100' 
                      : 'bg-rose-50 text-rose-700 border border-rose-100'
                  }`}>
                    {currentCheckIn.rating >= 4 ? 'Good' : currentCheckIn.rating === 3 ? 'Fair' : 'Severe'}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-2xl">
                    {currentCheckIn.rating === 5 ? '🌸' : currentCheckIn.rating === 4 ? '☀️' : currentCheckIn.rating === 3 ? '🌤️' : currentCheckIn.rating === 2 ? '🌧️' : '🌪️'}
                  </span>
                  <div className="text-xs font-bold text-brand-text-dark">
                    Feeling rating: <span className="text-brand-primary">{currentCheckIn.rating} / 5</span>
                  </div>
                </div>

                {currentCheckIn.note && (
                  <p className="text-xs text-brand-text-muted italic leading-relaxed">
                    "{currentCheckIn.note}"
                  </p>
                )}
              </div>
            ) : (
              <div className="p-4 bg-slate-50 border border-dashed rounded-2xl text-center text-xs text-brand-text-muted">
                No patient reports submitted recently.
              </div>
            )}

            {/* Micro-feed of Patient Checkins */}
            <div className="space-y-3">
              <div className="text-xs font-bold text-brand-text-muted uppercase tracking-wider">
                Historic Check-In Feed ({checkIns.length} logs)
              </div>
              <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-1">
                {checkIns.map((log, idx) => {
                  const stars = '★'.repeat(log.rating) + '☆'.repeat(5 - log.rating);
                  return (
                    <div
                      key={idx}
                      className="p-3 bg-white border border-brand-border rounded-xl space-y-1.5 hover:border-slate-300 transition-colors"
                    >
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] font-mono font-bold text-brand-text-muted">{log.date}</span>
                        <span className="text-[11px] font-bold text-amber-500 font-mono">{stars}</span>
                      </div>
                      {log.note && (
                        <p className="text-xs text-brand-text-dark font-medium italic">
                          "{log.note}"
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Disclaimer */}
            <div className="flex items-start gap-2 text-[10px] text-brand-text-muted leading-relaxed">
              <Heart className="w-3.5 h-3.5 text-brand-primary shrink-0 mt-0.5" />
              <span>
                Clinicians are advised to cross-reference patient-reported logs with clinical measurements during the consult.
              </span>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
}
