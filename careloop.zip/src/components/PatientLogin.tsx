import React, { useState } from 'react';
import { HeartPulse, ShieldCheck, Phone, User, LogIn, Sparkles } from 'lucide-react';

interface PatientLoginProps {
  onLogin: (name: string, phone: string, linkWhatsApp: boolean) => void;
}

const SAMPLE_PROFILES = [
  { name: 'Jane Doe', phone: '+14155238886', country: 'US (Twilio Sandbox)', desc: 'Pre-registered test patient' },
  { name: 'Arjun Mehta', phone: '+919876543210', country: 'India (+91)', desc: 'Cardiology recovery care' },
  { name: 'Sarah Connor', phone: '+15551234567', country: 'US (+1)', desc: 'Endocrinology treatment' },
];

export default function PatientLogin({ onLogin }: PatientLoginProps) {
  const [name, setName] = useState('');
  const [phonePrefix, setPhonePrefix] = useState('+91');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [linkWhatsApp, setLinkWhatsApp] = useState(true);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!name.trim()) {
      setError('Please enter your full name.');
      return;
    }

    const cleanPhone = phoneNumber.replace(/[^0-9]/g, '');
    if (!cleanPhone || cleanPhone.length < 8) {
      setError('Please enter a valid phone number (at least 8 digits).');
      return;
    }

    const fullPhone = `${phonePrefix}${cleanPhone}`;
    onLogin(name.trim(), fullPhone, linkWhatsApp);
  };

  const selectSampleProfile = (profile: typeof SAMPLE_PROFILES[0]) => {
    setName(profile.name);
    setLinkWhatsApp(true);
    
    // Parse prefix and number
    if (profile.phone.startsWith('+91')) {
      setPhonePrefix('+91');
      setPhoneNumber(profile.phone.slice(3));
    } else if (profile.phone.startsWith('+1')) {
      setPhonePrefix('+1');
      setPhoneNumber(profile.phone.slice(2));
    } else {
      setPhonePrefix('+');
      setPhoneNumber(profile.phone.slice(1));
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-4" id="patient-login-page">
      <div className="w-full max-w-lg bg-white border border-slate-100 rounded-[28px] shadow-xl shadow-slate-200/50 p-6 md:p-8 space-y-6 relative overflow-hidden transition-all duration-300">
        
        {/* Decorative background glow */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-teal-500/5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-teal-500/5 rounded-full blur-3xl pointer-events-none"></div>

        {/* Identity & Header */}
        <div className="text-center space-y-3 relative">
          <div className="mx-auto w-14 h-14 bg-teal-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-teal-600/15 border border-teal-500/10">
            <HeartPulse className="w-7 h-7 animate-pulse-slow" />
          </div>
          <div className="space-y-1">
            <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">Patient Secure Login</h2>
            <p className="text-xs text-brand-text-muted max-w-sm mx-auto">
              Access your personalized clinical timeline, book appointments, and enable real-time WhatsApp medication reminders.
            </p>
          </div>
        </div>

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-5 relative">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-100 rounded-xl text-rose-700 text-xs font-semibold animate-fade-in text-center">
              {error}
            </div>
          )}

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-600 uppercase tracking-wider font-mono flex items-center gap-1">
              <User className="w-3.5 h-3.5 text-teal-600" />
              Your Full Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Jane Doe"
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-teal-500 focus:bg-white rounded-xl text-sm font-semibold transition-all outline-none focus:ring-4 focus:ring-teal-500/10 text-slate-800"
              id="login-name-input"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-600 uppercase tracking-wider font-mono flex items-center gap-1">
              <Phone className="w-3.5 h-3.5 text-teal-600" />
              WhatsApp Phone Number
            </label>
            <div className="flex gap-2">
              <select
                value={phonePrefix}
                onChange={(e) => setPhonePrefix(e.target.value)}
                className="px-3 py-3 bg-slate-50 border border-slate-200 focus:border-teal-500 rounded-xl text-sm font-bold text-slate-700 outline-none transition-all cursor-pointer"
                id="login-country-prefix"
              >
                <option value="+91">🇮🇳 +91 (IN)</option>
                <option value="+1">🇺🇸 +1 (US)</option>
                <option value="+44">🇬🇧 +44 (UK)</option>
                <option value="+61">🇦🇺 +61 (AU)</option>
                <option value="+33">🇫🇷 +33 (FR)</option>
                <option value="+">Other</option>
              </select>
              <input
                type="tel"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="e.g. 9876543210"
                className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 focus:border-teal-500 focus:bg-white rounded-xl text-sm font-semibold transition-all outline-none focus:ring-4 focus:ring-teal-500/10 text-slate-800"
                id="login-phone-input"
              />
            </div>
            
            {/* Interactive WhatsApp link check */}
            <div className={`p-3 border rounded-xl flex items-center gap-2.5 text-left transition-all ${
              linkWhatsApp 
                ? 'bg-teal-50/60 border-teal-200' 
                : 'bg-slate-50 border-slate-200 opacity-75'
            }`}>
              <input
                type="checkbox"
                id="link-whatsapp-checkbox"
                checked={linkWhatsApp}
                onChange={(e) => setLinkWhatsApp(e.target.checked)}
                className="w-4 h-4 rounded border-slate-300 text-teal-600 focus:ring-teal-500 cursor-pointer"
              />
              <label htmlFor="link-whatsapp-checkbox" className="text-[11px] text-teal-850 font-bold leading-normal cursor-pointer select-none">
                🔗 Enable active WhatsApp linkage (Sends instant verification message now)
              </label>
            </div>

            <p className="text-[10px] text-brand-text-muted">
              Used strictly to dispatch medication alerts, check-in links, and appointment updates directly to your WhatsApp inbox.
            </p>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-teal-600/10 hover:shadow-teal-600/20 transition-all uppercase tracking-wider font-mono"
            id="login-submit-btn"
          >
            <LogIn className="w-4 h-4" />
            Enter CarePortal
          </button>
        </form>

        {/* Divider */}
        <div className="relative flex py-1 items-center">
          <div className="flex-grow border-t border-slate-100"></div>
          <span className="flex-shrink mx-4 text-[10px] text-slate-400 font-bold uppercase tracking-widest font-mono">
            Or Demo profiles
          </span>
          <div className="flex-grow border-t border-slate-100"></div>
        </div>

        {/* Demo profiles quick login */}
        <div className="space-y-2.5">
          <p className="text-[11px] text-brand-text-muted text-center font-semibold">
            Select a pre-registered testing profile to autofill and evaluate instantly:
          </p>
          <div className="grid grid-cols-1 gap-2">
            {SAMPLE_PROFILES.map((profile, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => selectSampleProfile(profile)}
                className="w-full text-left p-3.5 bg-slate-50/60 hover:bg-teal-50/30 border border-slate-100 hover:border-teal-200 rounded-xl flex items-center justify-between gap-3 cursor-pointer transition-all hover:scale-[1.01]"
                id={`demo-profile-btn-${idx}`}
              >
                <div className="space-y-0.5">
                  <div className="text-xs font-bold text-slate-850 flex items-center gap-1.5">
                    <span className="w-2 h-2 bg-teal-500 rounded-full"></span>
                    {profile.name}
                  </div>
                  <div className="text-[10px] text-brand-text-muted font-mono">
                    {profile.phone} • {profile.country}
                  </div>
                </div>
                <div className="text-right">
                  <span className="bg-slate-200/55 text-slate-600 text-[9px] font-bold px-2 py-0.5 rounded-full uppercase font-mono tracking-wide">
                    Autofill
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Consent, Privacy badge */}
        <div className="flex items-center justify-center gap-2 pt-2 text-[10px] text-slate-400 border-t border-slate-100">
          <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
          <span>Fully HIPAA Compliant • Your records are encrypted and protected</span>
        </div>
      </div>
    </div>
  );
}
