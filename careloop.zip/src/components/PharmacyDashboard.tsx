import React, { useState } from 'react';
import { Visit, Medication } from '../types';
import { 
  Search, Pill, FileText, CheckCircle, Clock, Truck, Shield, 
  Printer, AlertCircle, RefreshCw, Layers, CheckSquare
} from 'lucide-react';

interface PharmacyDashboardProps {
  visits: Visit[];
}

interface PharmacyOrder {
  id: string;
  patientName: string;
  visitId: string;
  visitDate: string;
  doctorName: string;
  medicationName: string;
  dosage: string;
  frequency: string;
  duration: string;
  slots: string[];
  status: 'pending' | 'ready' | 'dispensed';
  priority: 'High' | 'Normal';
  notes?: string;
}

export default function PharmacyDashboard({ visits }: PharmacyDashboardProps) {
  // We initialize the orders from the existing visits (Amoxicillin, Cetirizine, Ibuprofen, Hydrocortisone)
  // to populate a beautiful initial queue.
  const initialOrders: PharmacyOrder[] = [];
  
  // Flatten medications from all visits into standalone pharmacy orders
  visits.forEach((v) => {
    v.medications.forEach((med, idx) => {
      // Amoxicillin is high priority, others are normal
      const isHighPri = med.name.toLowerCase().includes('amoxicillin') || med.name.toLowerCase().includes('antibiotic');
      initialOrders.push({
        id: `ph-order-${v.id}-${idx}`,
        patientName: 'Default Patient',
        visitId: v.id,
        visitDate: v.date,
        doctorName: v.doctorName,
        medicationName: med.name,
        dosage: med.dosage,
        frequency: med.frequency,
        duration: med.duration,
        slots: med.slots,
        status: idx === 0 ? 'ready' : idx === 2 ? 'dispensed' : 'pending', // mix status for visual variation
        priority: isHighPri ? 'High' : 'Normal',
        notes: v.diagnosis ? `Prescribed for: ${v.diagnosis}` : undefined,
      });
    });
  });

  const [orders, setOrders] = useState<PharmacyOrder[]>(initialOrders);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'ready' | 'dispensed'>('all');
  const [selectedOrderForLabel, setSelectedOrderForLabel] = useState<PharmacyOrder | null>(null);

  // Sync state if new visits are added by doctor
  const refreshFromVisits = () => {
    const updatedOrders: PharmacyOrder[] = [];
    visits.forEach((v) => {
      v.medications.forEach((med, idx) => {
        // Check if we already have this order id
        const orderId = `ph-order-${v.id}-${idx}`;
        const existing = orders.find(o => o.id === orderId);
        
        if (existing) {
          updatedOrders.push(existing);
        } else {
          const isHighPri = med.name.toLowerCase().includes('amoxicillin') || med.name.toLowerCase().includes('antibiotic');
          updatedOrders.push({
            id: orderId,
            patientName: 'Default Patient',
            visitId: v.id,
            visitDate: v.date,
            doctorName: v.doctorName,
            medicationName: med.name,
            dosage: med.dosage,
            frequency: med.frequency,
            duration: med.duration,
            slots: med.slots,
            status: 'pending',
            priority: isHighPri ? 'High' : 'Normal',
            notes: `Prescribed for: ${v.diagnosis}`,
          });
        }
      });
    });
    setOrders(updatedOrders);
  };

  const updateOrderStatus = (orderId: string, newStatus: 'pending' | 'ready' | 'dispensed') => {
    setOrders(prev => prev.map(order => 
      order.id === orderId ? { ...order, status: newStatus } : order
    ));
    if (selectedOrderForLabel?.id === orderId) {
      setSelectedOrderForLabel(prev => prev ? { ...prev, status: newStatus } : null);
    }
  };

  // Filter logic
  const filteredOrders = orders.filter((o) => {
    const matchesSearch = 
      o.medicationName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.doctorName.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' ? true : o.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  // Calculate statistics
  const countPending = orders.filter(o => o.status === 'pending').length;
  const countReady = orders.filter(o => o.status === 'ready').length;
  const countDispensed = orders.filter(o => o.status === 'dispensed').length;

  return (
    <div className="space-y-8 animate-fade-in" id="pharmacy-dashboard">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-[24px] p-6 text-white shadow-lg border border-slate-700/50 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="bg-teal-500/20 text-teal-300 border border-teal-500/30 text-[10px] font-extrabold px-3 py-1 rounded-full uppercase tracking-wider">
              Pharmacy Dispensary
            </span>
            <span className="text-slate-400 font-mono text-[11px] font-bold">
              Secure Rx Verification Protocol
            </span>
          </div>
          <h2 className="text-2xl font-bold tracking-tight">CareLoop Pharmacy Dashboard</h2>
          <p className="text-xs text-slate-300 font-medium">
            Verify prescriptions, print smart directions labels, and manage dispensing logistics.
          </p>
        </div>

        <button
          onClick={refreshFromVisits}
          className="px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-sm shadow-teal-600/10 transition-all self-start md:self-center"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Sync Doctor Rx Queue
        </button>
      </div>

      {/* Counters & Stats Ribbon */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4" id="pharmacy-stats">
        
        <div className="sleek-card p-4.5 flex items-center gap-4">
          <div className="w-10 h-10 bg-slate-50 border border-brand-border rounded-xl flex items-center justify-center text-slate-500 font-bold text-sm">
            <Layers className="w-5 h-5 text-slate-500" />
          </div>
          <div>
            <div className="text-[10px] text-brand-text-muted font-bold uppercase tracking-wider">Total Rx Orders</div>
            <div className="text-lg font-bold text-brand-text-dark">{orders.length}</div>
          </div>
        </div>

        <div className="sleek-card p-4.5 flex items-center gap-4">
          <div className="w-10 h-10 bg-amber-50 border border-amber-100 rounded-xl flex items-center justify-center text-amber-500">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] text-amber-700 font-bold uppercase tracking-wider">Pending Prep</div>
            <div className="text-lg font-bold text-amber-700">{countPending}</div>
          </div>
        </div>

        <div className="sleek-card p-4.5 flex items-center gap-4">
          <div className="w-10 h-10 bg-blue-50 border border-blue-100 rounded-xl flex items-center justify-center text-blue-500">
            <Truck className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] text-blue-700 font-bold uppercase tracking-wider">Ready for Pickup</div>
            <div className="text-lg font-bold text-blue-700">{countReady}</div>
          </div>
        </div>

        <div className="sleek-card p-4.5 flex items-center gap-4">
          <div className="w-10 h-10 bg-emerald-50 border border-emerald-100 rounded-xl flex items-center justify-center text-emerald-500">
            <CheckCircle className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] text-emerald-700 font-bold uppercase tracking-wider">Dispensed Today</div>
            <div className="text-lg font-bold text-emerald-700">{countDispensed}</div>
          </div>
        </div>

      </div>

      {/* Main Grid: Left is Queue, Right is Print Simulator */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Queue list */}
        <div className="lg:col-span-8 space-y-4">
          
          {/* Controls bar */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white border border-brand-border p-4 rounded-2xl">
            {/* Search Input */}
            <div className="relative flex-1 max-w-md">
              <input
                type="text"
                placeholder="Search prescription or clinician..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-brand-border rounded-xl text-xs text-brand-text-dark font-semibold focus:outline-none focus:ring-2 focus:ring-teal-500/20"
              />
              <Search className="w-4 h-4 text-brand-text-muted absolute left-3 top-1/2 -translate-y-1/2" />
            </div>

            {/* Status Tabs */}
            <div className="flex items-center gap-1.5 bg-slate-50 p-1 border border-brand-border rounded-xl">
              {(['all', 'pending', 'ready', 'dispensed'] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setStatusFilter(tab)}
                  className={`px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase transition-all cursor-pointer ${
                    statusFilter === tab
                      ? 'bg-slate-800 text-white shadow-sm'
                      : 'text-brand-text-muted hover:text-brand-text-dark'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          {/* Rx Queue Rows */}
          <div className="space-y-3">
            {filteredOrders.length === 0 ? (
              <div className="sleek-card p-12 text-center">
                <Pill className="w-12 h-12 text-slate-200 mx-auto mb-3" />
                <p className="font-bold text-brand-text-dark">No matching prescriptions</p>
                <p className="text-xs text-brand-text-muted mt-1">
                  Adjust your search or filter criteria to see other prescription records.
                </p>
              </div>
            ) : (
              filteredOrders.map((order) => {
                const isActiveForLabel = selectedOrderForLabel?.id === order.id;
                return (
                  <div
                    key={order.id}
                    className={`sleek-card p-5 transition-all flex flex-col md:flex-row justify-between md:items-center gap-4 ${
                      isActiveForLabel ? 'ring-2 ring-teal-500 border-teal-500 shadow-md' : 'hover:shadow-md'
                    }`}
                  >
                    {/* Medication Detail */}
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${
                          order.status === 'pending'
                            ? 'bg-amber-50 text-amber-700 border border-amber-100'
                            : order.status === 'ready'
                            ? 'bg-blue-50 text-blue-700 border border-blue-100'
                            : 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                        }`}>
                          {order.status.toUpperCase()}
                        </span>

                        <span className="text-[10px] text-brand-text-muted font-bold uppercase tracking-wider font-mono">
                          Prescribed {order.visitDate}
                        </span>

                        {order.priority === 'High' && (
                          <span className="bg-rose-50 text-rose-700 border border-rose-100 text-[9px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 animate-pulse">
                            <AlertCircle className="w-2.5 h-2.5" />
                            CRITICAL RX
                          </span>
                        )}
                      </div>

                      <h4 className="font-bold text-brand-text-dark text-base tracking-tight flex items-center gap-2">
                        <Pill className="w-4 h-4 text-teal-600 shrink-0" />
                        {order.medicationName}
                      </h4>

                      <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-brand-text-muted font-medium">
                        <div>Dosage: <span className="font-semibold text-brand-text-dark">{order.dosage}</span></div>
                        <div>Duration: <span className="font-semibold text-brand-text-dark">{order.duration}</span></div>
                        <div className="col-span-2">Instructions: <span className="font-semibold text-brand-text-dark">{order.frequency}</span></div>
                        <div className="col-span-2 flex items-center gap-1 mt-1">
                          <span className="text-[10px] text-brand-text-muted uppercase font-bold tracking-wider">Scheduled times:</span>
                          {order.slots.map(s => (
                            <span key={s} className="px-1.5 py-0.5 bg-slate-50 border text-[9px] rounded-md font-bold text-slate-500 uppercase">
                              {s}
                            </span>
                          ))}
                        </div>
                      </div>

                      {order.notes && (
                        <p className="text-[10px] bg-slate-50 px-2.5 py-1.5 rounded-lg border border-brand-border text-brand-text-muted font-semibold">
                          {order.notes}
                        </p>
                      )}

                      <div className="text-[10px] text-slate-400">
                        Prescribed by: <span className="font-semibold text-slate-500">{order.doctorName}</span>
                      </div>
                    </div>

                    {/* Actions and Print selectors */}
                    <div className="flex flex-col gap-2 shrink-0 self-start md:self-center">
                      <div className="flex gap-1.5">
                        {order.status === 'pending' && (
                          <button
                            onClick={() => updateOrderStatus(order.id, 'ready')}
                            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-[10px] uppercase rounded-lg cursor-pointer"
                          >
                            Mark Ready
                          </button>
                        )}
                        {order.status === 'ready' && (
                          <button
                            onClick={() => updateOrderStatus(order.id, 'dispensed')}
                            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] uppercase rounded-lg cursor-pointer"
                          >
                            Dispense to Pt
                          </button>
                        )}
                        {order.status === 'dispensed' && (
                          <div className="text-[10px] font-bold text-emerald-600 flex items-center gap-1 py-1">
                            <CheckCircle className="w-3.5 h-3.5" />
                            Dispensed
                          </div>
                        )}
                        
                        {/* Reset action in case of testing */}
                        {order.status !== 'pending' && (
                          <button
                            onClick={() => updateOrderStatus(order.id, 'pending')}
                            className="text-[10px] text-slate-400 hover:text-slate-600 underline font-semibold cursor-pointer py-1 ml-1"
                          >
                            Reset
                          </button>
                        )}
                      </div>

                      <button
                        onClick={() => setSelectedOrderForLabel(order)}
                        className="px-3 py-1.5 border border-brand-border hover:border-slate-350 text-brand-text-dark bg-slate-50/80 font-bold text-[10px] uppercase rounded-lg flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <Printer className="w-3 h-3" />
                        Print Safety Label
                      </button>
                    </div>

                  </div>
                );
              })
            )}
          </div>

        </div>

        {/* Right Label Print Simulator */}
        <div className="lg:col-span-4">
          <div className="sleek-card sticky top-24 space-y-6">
            
            <div>
              <div className="flex items-center gap-1 font-bold text-xs text-teal-600 uppercase tracking-wider mb-1">
                <Printer className="w-4 h-4" />
                Vial Label Simulator
              </div>
              <h3 className="font-bold text-brand-text-dark text-base">Print Smart Directions</h3>
              <p className="text-xs text-brand-text-muted">
                Select any prescription from the active dispensary queue to review and print compliant pharmaceutical directions container labels.
              </p>
            </div>

            {selectedOrderForLabel ? (
              <div className="space-y-6">
                
                {/* Physical Label Mockup container */}
                <div className="border border-slate-300 bg-white p-5 rounded-2xl shadow-sm space-y-4 font-sans relative overflow-hidden">
                  
                  {/* Decorative Rx stripe */}
                  <div className="absolute top-0 left-0 right-0 h-1.5 bg-amber-500"></div>

                  <div className="flex justify-between items-start pt-1">
                    <div>
                      <h4 className="font-extrabold text-[13px] tracking-tight text-slate-900 uppercase">CARELOOP PHARMACY</h4>
                      <p className="text-[9px] text-slate-400 font-semibold uppercase tracking-wider">TEL: +1 (555) 123-LOOP</p>
                    </div>
                    <div className="text-right">
                      <span className="font-mono text-[9px] font-bold text-slate-500">RX#: {selectedOrderForLabel.id.split('-').slice(2).join('')}</span>
                    </div>
                  </div>

                  <div className="border-t border-dashed border-slate-200 pt-3 space-y-1">
                    <div className="text-[9px] text-slate-400 font-extrabold uppercase tracking-wider">PATIENT</div>
                    <div className="text-sm font-bold text-slate-800">{selectedOrderForLabel.patientName}</div>
                  </div>

                  <div className="space-y-1 border-t border-dashed border-slate-200 pt-3">
                    <div className="text-[9px] text-slate-400 font-extrabold uppercase tracking-wider font-sans">DRUG DIRECTIVES</div>
                    <div className="text-xs font-black text-emerald-700 uppercase tracking-tight">{selectedOrderForLabel.medicationName}</div>
                    <p className="text-[11px] font-bold text-slate-700 leading-relaxed bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      Take {selectedOrderForLabel.dosage} ({selectedOrderForLabel.frequency}) for {selectedOrderForLabel.duration}.
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-4 border-t border-dashed border-slate-200 pt-3 text-[10px]">
                    <div>
                      <span className="text-[8px] text-slate-400 font-bold block uppercase">PRESCRIBER</span>
                      <span className="font-bold text-slate-700">{selectedOrderForLabel.doctorName}</span>
                    </div>
                    <div>
                      <span className="text-[8px] text-slate-400 font-bold block uppercase">DATE FILLED</span>
                      <span className="font-bold text-slate-700">{selectedOrderForLabel.visitDate}</span>
                    </div>
                  </div>

                  {/* Simulated barcode */}
                  <div className="pt-3 border-t border-dashed border-slate-200 flex flex-col items-center justify-center space-y-1">
                    <div className="bg-slate-900 w-full h-8 flex items-center justify-between px-2 font-mono text-[6px] text-slate-900 select-none overflow-hidden opacity-80">
                      ||| |||| | | |||| || ||| | ||| |||| || | || |||| | ||| | |||| ||||
                    </div>
                    <span className="text-[8px] text-slate-400 font-mono tracking-widest">{selectedOrderForLabel.id.toUpperCase()}</span>
                  </div>

                </div>

                {/* Print confirmation */}
                <button
                  onClick={() => {
                    alert(`Label successfully printed for ${selectedOrderForLabel.medicationName}! Prescribing directions synchronized and ready for checkout.`);
                  }}
                  className="w-full py-2.5 bg-slate-800 hover:bg-slate-900 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-sm shadow-slate-800/10 transition-all"
                >
                  <Printer className="w-4 h-4" />
                  Print Physical Label
                </button>

              </div>
            ) : (
              <div className="py-12 text-center text-brand-text-muted text-sm border border-dashed rounded-2xl border-slate-200">
                <Printer className="w-10 h-10 text-slate-200 mx-auto mb-3" />
                <p>No prescription selected.</p>
                <p className="text-xs text-brand-text-muted mt-1">Select "Print Safety Label" from the active queue.</p>
              </div>
            )}

            {/* General Pharmacy Compliance info */}
            <div className="p-4 bg-emerald-50/50 border border-emerald-100 rounded-2xl space-y-2 text-xs">
              <div className="flex items-center gap-1.5 font-bold text-emerald-800 uppercase text-[10px] tracking-wider">
                <Shield className="w-3.5 h-3.5" />
                Dispensing Regulations
              </div>
              <p className="text-emerald-700 leading-relaxed text-[11px] font-semibold">
                This applet implements standard e-prescribing validation protocols. Real-time patient compliance tasks are populated in the patient's schedule immediately upon clinician signoff.
              </p>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
}
