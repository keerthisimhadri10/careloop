import React, { useState, useEffect } from 'react';
import { Visit, MedicationTask } from '../types';
import {
  Sparkles,
  CheckSquare,
  Square,
  Clock,
  Calendar,
  AlertTriangle,
  RotateCcw,
  Coffee,
  Sun,
  Moon,
  Info,
  CheckCircle2,
  Bell,
  Phone,
  Check,
  CheckCheck,
  Smartphone,
  RefreshCw,
  Send,
  Upload,
  FileText,
  X,
  AlertCircle,
  Plus,
} from 'lucide-react';

interface RemindersProps {
  visits: Visit[];
  medicationTasks: MedicationTask[];
  onToggleTask: (taskId: string) => void;
  onResetTasks: () => void;
  simplifiedNotesText?: string;
  curedMedications: string[];
  onCureMedication: (medicationName: string) => void;
  currentUser?: { name: string; phone: string } | null;
  onAddMedications?: (newMeds: Array<{ medicationName: string; dosage: string; slot: string }>) => void;
}

export default function Reminders({
  visits,
  medicationTasks,
  onToggleTask,
  onResetTasks,
  simplifiedNotesText,
  curedMedications = [],
  onCureMedication,
  currentUser,
  onAddMedications,
}: RemindersProps) {
  const [activeTab, setActiveTab] = useState<'all' | 'morning' | 'afternoon' | 'evening'>('all');

  // AI Prescription Upload and Analyzer State
  const [isDragging, setIsDragging] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<{ name: string; preview: string; type: string } | null>(null);
  const [extractedMeds, setExtractedMeds] = useState<any[] | null>(null);
  const [uploadError, setUploadError] = useState<string>('');

  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setUploadError('Please upload an image file (PNG, JPG, WebP).');
      return;
    }
    setUploadError('');
    const reader = new FileReader();
    reader.onload = () => {
      setUploadedFile({
        name: file.name,
        preview: reader.result as string,
        type: file.type
      });
      setExtractedMeds(null);
    };
    reader.readAsDataURL(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleAnalyzePrescription = async () => {
    if (!uploadedFile) return;
    setIsAnalyzing(true);
    setUploadError('');
    try {
      const response = await fetch('/api/analyze-prescription', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          fileData: uploadedFile.preview,
          mimeType: uploadedFile.type
        })
      });
      const data = await response.json();
      if (response.ok && data.medications) {
        setExtractedMeds(data.medications);
      } else {
        setUploadError(data.error || 'Failed to analyze prescription. Please check image clarity.');
      }
    } catch (err: any) {
      console.error(err);
      setUploadError('Failed to connect to AI server. Please verify your environment settings.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleConfirmSchedule = () => {
    if (!extractedMeds || !onAddMedications) return;
    onAddMedications(extractedMeds);
    setUploadedFile(null);
    setExtractedMeds(null);
  };

  const [waLogs, setWaLogs] = useState<any[]>([]);
  const [pendingCount, setPendingCount] = useState(0);

  const fetchLogs = () => {
    if (!currentUser) return;
    fetch(`/api/whatsapp/logs?phone=${encodeURIComponent(currentUser.phone)}`)
      .then((res) => res.json())
      .then((data) => {
        setWaLogs(data.logs || []);
        setPendingCount(data.pendingCount || 0);
      })
      .catch((err) => console.error('Error fetching logs:', err));
  };

  useEffect(() => {
    fetchLogs();
    const interval = setInterval(fetchLogs, 2500);
    return () => clearInterval(interval);
  }, [currentUser?.phone]);

  // Automated Missed Dose Tracker States
  const [autoAlertedIds, setAutoAlertedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('careloop_auto_alerted_ids');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const saveAutoAlertedIds = (ids: string[]) => {
    setAutoAlertedIds(ids);
    localStorage.setItem('careloop_auto_alerted_ids', JSON.stringify(ids));
  };

  const [simulatedHour, setSimulatedHour] = useState<string>(() => {
    return localStorage.getItem('careloop_simulated_hour') || '08:00 AM';
  });

  const triggerMissedDoseAlert = async (task: MedicationTask, isAuto = false) => {
    if (!currentUser) return;
    const webLink = window.location.href;
    try {
      const response = await fetch('/api/whatsapp/trigger-missed-dose', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          patientName: currentUser.name,
          patientPhone: currentUser.phone,
          medicationName: task.medicationName,
          dosage: task.dosage,
          slot: task.slot,
          webLink,
        }),
      });
      const data = await response.json();
      if (data.success) {
        if (isAuto) {
          console.log(`[AUTO REMINDER DISPATCHED] Missed ${task.medicationName} (${task.slot})`);
        } else {
          alert(`🔔 Outbound WhatsApp Adherence alerts triggered!\n\nMessage #1 sent immediately to ${currentUser.phone}.\n\nMessage #2 (+5 mins) and Message #3 (+10 mins) have been scheduled. Fast-forward below to view!`);
        }
        fetchLogs();
      } else {
        if (!isAuto) {
          alert(`Error: ${data.error || 'Failed to dispatch alert.'}`);
        }
      }
    } catch (err: any) {
      console.error('Trigger Alert error:', err);
      if (!isAuto) {
        alert(`Error triggering alerts: ${err.message}`);
      }
    }
  };

  const checkAutoMissedDoses = (hourStr: string) => {
    if (!currentUser) return;

    let currentAlertedIds: string[] = [];
    try {
      const saved = localStorage.getItem('careloop_auto_alerted_ids');
      currentAlertedIds = saved ? JSON.parse(saved) : [];
    } catch {
      currentAlertedIds = [];
    }

    const missedSlots: string[] = [];
    // Map simulated hours to active slots that are now considered missed
    if (['11:00 AM', '01:00 PM', '03:00 PM', '06:00 PM', '10:00 PM'].includes(hourStr)) {
      missedSlots.push('morning');
    }
    if (['03:00 PM', '06:00 PM', '10:00 PM'].includes(hourStr)) {
      missedSlots.push('afternoon');
    }
    if (['10:00 PM'].includes(hourStr)) {
      missedSlots.push('evening');
    }

    const newlyTriggered: string[] = [];
    medicationTasks.forEach((task) => {
      if (!task.checked && missedSlots.includes(task.slot) && !currentAlertedIds.includes(task.id)) {
        newlyTriggered.push(task.id);
        triggerMissedDoseAlert(task, true);
      }
    });

    if (newlyTriggered.length > 0) {
      const updated = [...currentAlertedIds, ...newlyTriggered];
      saveAutoAlertedIds(updated);
    }
  };

  const handleSimulatedHourChange = (newHour: string) => {
    setSimulatedHour(newHour);
    localStorage.setItem('careloop_simulated_hour', newHour);
    checkAutoMissedDoses(newHour);
  };

  const handleFastForward = async () => {
    if (!currentUser) return;
    try {
      const response = await fetch('/api/whatsapp/fast-forward', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          phone: currentUser.phone,
        }),
      });
      const data = await response.json();
      if (data.success) {
        alert(`⏰ Time Fast-Forwarded 5 Mins!\n\n${data.message}`);
        fetchLogs();
      } else {
        alert(data.message || 'No pending scheduled messages to trigger.');
      }
    } catch (err: any) {
      console.error('Fast-forward error:', err);
    }
  };

  const handleResetLogs = async () => {
    try {
      const response = await fetch('/api/whatsapp/reset', { method: 'POST' });
      const data = await response.json();
      if (data.success) {
        alert('🧹 WhatsApp log queue has been reset.');
        setWaLogs([]);
        setPendingCount(0);
      }
    } catch (err: any) {
      console.error('Reset logs error:', err);
    }
  };

  // Find the most recent visit with simplified notes to display as active guidance
  const latestVisitWithNotes = visits.find((v) => v.simplifiedNotes) || visits[0];

  // Current system date for comparison is 2026-07-05
  const CURRENT_DATE_STR = '2026-07-05';

  // Highlight follow-ups that are within 3 days of CURRENT_DATE_STR
  const getFollowUpAlert = (): { visit: Visit; daysLeft: number } | null => {
    if (visits.length === 0) return null;

    const today = new Date(CURRENT_DATE_STR);

    for (const visit of visits) {
      if (visit.followUpDate) {
        const followUp = new Date(visit.followUpDate);
        const diffTime = followUp.getTime() - today.getTime();
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

        // If follow-up date is in the future and within 3 days (0 to 3 days)
        if (diffDays >= 0 && diffDays <= 3) {
          return { visit, daysLeft: diffDays };
        }
      }
    }
    return null;
  };

  const followUpAlert = getFollowUpAlert();

  // Filter tasks based on selected slot tab
  const filteredTasks = medicationTasks.filter((task) => {
    if (activeTab === 'all') return true;
    return task.slot === activeTab;
  });

  const totalTasks = medicationTasks.length;
  const completedTasks = medicationTasks.filter((t) => t.checked).length;
  const completionPercentage = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  return (
    <div className="space-y-6" id="reminders-view">
      {/* 3-Day Follow-Up Alert Banner */}
      {followUpAlert && (
        <div className="bg-gradient-to-r from-amber-500 to-orange-600 rounded-[20px] p-5 text-white shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4 border border-amber-400/20 animate-pulse-slow" id="follow-up-alert-banner">
          <div className="flex items-start gap-3.5">
            <div className="p-3 bg-white/10 rounded-2xl shrink-0">
              <AlertTriangle className="w-6 h-6 text-white" />
            </div>
            <div className="space-y-0.5">
              <h3 className="font-bold tracking-tight text-sm md:text-base">Upcoming Follow-Up Recommended!</h3>
              <p className="text-xs text-amber-50/90 leading-relaxed">
                Your suggested follow-up appointment with <strong className="text-white">{followUpAlert.visit.doctorName} ({followUpAlert.visit.specialty})</strong> is scheduled or recommended in{' '}
                <span className="font-bold underline text-white">
                  {followUpAlert.daysLeft === 0
                    ? 'today!'
                    : followUpAlert.daysLeft === 1
                    ? '1 day (tomorrow)'
                    : `${followUpAlert.daysLeft} days`}
                </span>{' '}
                ({followUpAlert.visit.followUpDate}).
              </p>
            </div>
          </div>
          <span className="bg-white/15 hover:bg-white/20 border border-white/20 px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap self-start md:self-center cursor-pointer transition-colors">
            Book Appointment Slot
          </span>
        </div>
      )}

      {/* Main Grid: Checklist & AI Guidance */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Daily Medication checklist */}
        <div className="lg:col-span-7 sleek-card space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-brand-border pb-4">
            <div>
              <h2 className="font-bold text-brand-text-dark text-lg tracking-tight">Today's Medication Schedule</h2>
              <p className="text-xs text-brand-text-muted">Keep track of your daily doses. Checked-off items represent completed intakes.</p>
            </div>

            <button
              onClick={() => {
                onResetTasks();
                saveAutoAlertedIds([]);
              }}
              className="inline-flex items-center gap-1 text-xs font-bold text-brand-primary hover:text-brand-hover bg-brand-primary-light border border-brand-primary/20 px-3 py-1.5 rounded-xl cursor-pointer transition-all self-start sm:self-center"
              id="btn-reset-checklist"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset Checklist
            </button>
          </div>

          {/* Progress Indicator */}
          {totalTasks > 0 && (
            <div className="p-4 bg-slate-50/80 border border-brand-border rounded-2xl flex items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="text-xs font-bold text-brand-text-dark">Daily Compliance Progress</div>
                <div className="text-[11px] text-brand-text-muted font-bold">
                  {completedTasks} of {totalTasks} doses taken today ({completionPercentage}%)
                </div>
              </div>
              <div className="relative w-12 h-12 flex items-center justify-center shrink-0">
                {/* SVG Progress Circle */}
                <svg className="w-full h-full -rotate-90">
                  <circle
                    cx="24"
                    cy="24"
                    r="20"
                    stroke="#e2e8f0"
                    strokeWidth="4"
                    fill="transparent"
                  />
                  <circle
                    cx="24"
                    cy="24"
                    r="20"
                    stroke="#0d9488"
                    strokeWidth="4"
                    fill="transparent"
                    strokeDasharray={125.6}
                    strokeDashoffset={125.6 - (125.6 * completionPercentage) / 100}
                    className="transition-all duration-500"
                  />
                </svg>
                <span className="absolute text-[10px] font-bold text-brand-primary">{completionPercentage}%</span>
              </div>
            </div>
          )}

          {/* Automated Intake Simulator & WhatsApp Connection Panel */}
          <div className="p-4.5 bg-gradient-to-r from-teal-50/60 to-emerald-50/40 border border-teal-100/80 rounded-2xl space-y-3" id="automated-adherence-coordinator">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="flex h-2 w-2 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-teal-500"></span>
                </span>
                <span className="text-xs font-bold text-teal-950 flex items-center gap-1.5">
                  Automated Adherence Monitor
                </span>
              </div>
              <span className="bg-teal-600 text-white font-mono font-bold text-[9px] px-2 py-0.5 rounded-full uppercase tracking-wider">
                Active & Linked
              </span>
            </div>

            <p className="text-[11px] text-teal-900/80 leading-relaxed text-left">
              CareLoop automatically monitors unchecked medication tasks. When simulated time advances past a dosage's scheduled slot, a real-time WhatsApp alert is automatically dispatched to <strong className="text-teal-950 font-bold">{currentUser?.phone}</strong> containing a secure website link for verification.
            </p>

            <div className="space-y-2 pt-1 text-left">
              <label className="block text-[9px] font-extrabold text-teal-800 tracking-wider uppercase font-mono">
                🕒 Set Simulated Clock Time
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { label: '🌅 08:00 AM', value: '08:00 AM', sub: 'Early' },
                  { label: '⚠️ 11:00 AM', value: '11:00 AM', sub: 'Morning Missed' },
                  { label: '🌤️ 01:00 PM', value: '01:00 PM', sub: 'Noon' },
                  { label: '⚠️ 03:00 PM', value: '03:00 PM', sub: 'Afternoon Missed' },
                  { label: '🌇 06:00 PM', value: '06:00 PM', sub: 'Evening' },
                  { label: '⚠️ 10:00 PM', value: '10:00 PM', sub: 'Night Missed' },
                ].map((time) => {
                  const active = simulatedHour === time.value;
                  return (
                    <button
                      key={time.value}
                      onClick={() => handleSimulatedHourChange(time.value)}
                      className={`px-2 py-1.5 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                        active
                          ? 'bg-teal-700 border-teal-700 text-white shadow-sm font-bold'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-teal-50 hover:border-teal-300'
                      }`}
                      type="button"
                    >
                      <span className="text-[10px] font-bold">{time.label}</span>
                      <span className={`text-[8px] font-medium leading-none mt-0.5 ${active ? 'text-teal-100' : 'text-slate-400'}`}>
                        {time.sub}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Simulated Live Alert Banner */}
            {autoAlertedIds.length > 0 && (
              <div className="p-3 bg-white border border-teal-100 rounded-xl space-y-1.5 text-left animate-fade-in">
                <div className="text-[10px] font-bold text-teal-850 flex items-center gap-1.5">
                  <span className="text-xs">📢</span>
                  <span>Automated Reminders Dispatched ({autoAlertedIds.length})</span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {autoAlertedIds.map((id) => {
                    const task = medicationTasks.find((t) => t.id === id);
                    if (!task) return null;
                    return (
                      <span key={id} className="inline-flex items-center gap-1 bg-teal-50 text-teal-800 text-[9px] font-black px-2 py-1 rounded-lg border border-teal-200 font-mono">
                        📲 {task.medicationName} ({task.slot})
                      </span>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Time Slot Tabs Filter */}
          <div className="flex gap-1 bg-slate-50 border border-brand-border p-1 rounded-xl">
            {(['all', 'morning', 'afternoon', 'evening'] as const).map((tab) => {
              const active = activeTab === tab;
              const label = tab.charAt(0).toUpperCase() + tab.slice(1);
              return (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`flex-1 text-center py-2 text-xs font-bold rounded-lg transition-all capitalize flex items-center justify-center gap-1 cursor-pointer ${
                    active
                      ? 'bg-white text-brand-text-dark shadow-sm'
                      : 'text-brand-text-muted hover:text-brand-text-dark'
                  }`}
                >
                  {tab === 'morning' && <Coffee className="w-3 h-3 text-amber-500" />}
                  {tab === 'afternoon' && <Sun className="w-3 h-3 text-orange-500" />}
                  {tab === 'evening' && <Moon className="w-3 h-3 text-indigo-500" />}
                  {label}
                </button>
              );
            })}
          </div>

          {/* Checklist Task Items */}
          {filteredTasks.length === 0 ? (
            <div className="py-12 border border-dashed border-brand-border rounded-2xl text-center text-brand-text-muted text-xs">
              No medications scheduled for {activeTab === 'all' ? 'today' : `the ${activeTab}`}.
            </div>
          ) : (
            <div className="space-y-3" id="medication-checklist-container">
              {filteredTasks.map((task) => (
                <div
                  key={task.id}
                  id={`checklist-item-${task.id}`}
                  onClick={() => onToggleTask(task.id)}
                  className={`p-4 bg-white border rounded-2xl flex items-center justify-between cursor-pointer transition-all ${
                    task.checked
                      ? 'border-emerald-200 bg-emerald-50/20 opacity-80 shadow-inner'
                      : 'border-brand-border hover:border-slate-300 hover:shadow-sm'
                  }`}
                >
                  <div className="flex items-start gap-3.5">
                    <button className="shrink-0 mt-0.5" id={`check-btn-${task.id}`}>
                      {task.checked ? (
                        <CheckSquare className="w-5 h-5 text-brand-primary fill-teal-50" />
                      ) : (
                        <Square className="w-5 h-5 text-slate-300 hover:text-slate-400 bg-white" />
                      )}
                    </button>
                    <div>
                      <h4
                        className={`text-sm font-bold tracking-tight ${
                          task.checked ? 'line-through text-brand-text-muted' : 'text-brand-text-dark'
                        }`}
                      >
                        {task.medicationName}
                      </h4>
                      <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-brand-text-muted mt-1">
                        <span className="font-bold text-brand-text-dark bg-slate-100 px-1.5 py-0.5 rounded text-[10px]">
                          Dosage: {task.dosage}
                        </span>
                        <span className="inline-flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span className="capitalize">{task.slot}</span>
                        </span>
                      </div>

                      {!task.checked && currentUser && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            triggerMissedDoseAlert(task);
                          }}
                          className="mt-2.5 text-[10px] font-extrabold text-teal-800 bg-teal-50 hover:bg-teal-100/80 px-2.5 py-1.5 rounded-lg border border-teal-200/50 flex items-center gap-1.5 transition-all cursor-pointer hover:scale-[1.02] shadow-sm shadow-teal-700/5"
                          id={`trigger-alert-btn-${task.id}`}
                        >
                          <Bell className="w-3.5 h-3.5 text-teal-600 animate-pulse" />
                          Simulate Missed Dose (Trigger 3x WhatsApp reminders)
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Slot pill */}
                  <span
                    className={`text-[9px] font-bold px-2 py-0.5 rounded-full uppercase shrink-0 ${
                      task.slot === 'morning'
                        ? 'bg-amber-50 text-amber-700 border border-amber-100'
                        : task.slot === 'afternoon'
                        ? 'bg-orange-50 text-orange-700 border border-orange-100'
                        : 'bg-indigo-50 text-indigo-700 border border-indigo-100'
                    }`}
                  >
                    {task.slot}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* AI-Powered Explanations Panel */}
        <div className="lg:col-span-5 space-y-6">
          {/* AI Prescription Upload & Analyzer Panel */}
          <div className="sleek-card space-y-4" id="ai-prescription-card">
            <div className="flex items-center justify-between border-b border-brand-border pb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-teal-600 animate-pulse" />
                <h3 className="font-bold text-brand-text-dark text-sm md:text-base tracking-tight">
                  AI Prescription Scheduler
                </h3>
              </div>
              <span className="bg-teal-50 text-teal-700 text-[10px] font-bold px-2 py-0.5 rounded-full border border-teal-100 font-mono">
                Gemini Multi-Modal
              </span>
            </div>

            <p className="text-xs text-brand-text-muted leading-relaxed text-left">
              Upload a clear photo or copy of your prescription. Our medical AI will identify the medicine, dosage, and intake timings to configure your schedule automatically.
            </p>

            {/* Drag and Drop Zone */}
            {!uploadedFile ? (
              <div
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all ${
                  isDragging
                    ? 'border-teal-500 bg-teal-50/50'
                    : 'border-slate-200 hover:border-teal-400 hover:bg-slate-50/40'
                }`}
                onClick={() => document.getElementById('prescription-file-input')?.click()}
              >
                <input
                  type="file"
                  id="prescription-file-input"
                  className="hidden"
                  accept="image/*"
                  onChange={handleFileChange}
                />
                <div className="space-y-3">
                  <div className="w-12 h-12 bg-teal-50 text-teal-600 rounded-full flex items-center justify-center mx-auto shadow-sm">
                    <Upload className="w-6 h-6" />
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-slate-800">
                      Drag & drop your prescription image
                    </p>
                    <p className="text-[10px] text-slate-500">
                      or <span className="text-teal-600 font-bold underline">browse files</span> (PNG, JPG, WebP)
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-4 border border-brand-border p-4 rounded-2xl bg-slate-50/50">
                {/* File Info & Preview */}
                <div className="flex items-center justify-between gap-3 bg-white p-2.5 rounded-xl border border-slate-100">
                  <div className="flex items-center gap-2 overflow-hidden">
                    <img
                      src={uploadedFile.preview}
                      alt="Prescription preview"
                      className="w-10 h-10 object-cover rounded-lg border border-slate-200"
                    />
                    <div className="text-left overflow-hidden">
                      <p className="text-xs font-bold text-slate-800 truncate max-w-[150px]">
                        {uploadedFile.name}
                      </p>
                      <p className="text-[9px] text-slate-500 font-mono">
                        Ready to analyze
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => {
                        setUploadedFile(null);
                        setExtractedMeds(null);
                        setUploadError('');
                      }}
                      className="p-1 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-all"
                      title="Remove file"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Analyze Action Button */}
                {!extractedMeds && !isAnalyzing && (
                  <button
                    onClick={handleAnalyzePrescription}
                    className="w-full py-2.5 px-4 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all shadow-sm cursor-pointer"
                  >
                    <Sparkles className="w-4 h-4" />
                    Analyze with Gemini AI
                  </button>
                )}

                {/* Loading / Analyzing State */}
                {isAnalyzing && (
                  <div className="space-y-2 py-3 text-center">
                    <div className="flex items-center justify-center gap-2 text-teal-600 font-bold text-xs">
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Reading prescription details...</span>
                    </div>
                    <p className="text-[10px] text-slate-500 leading-normal animate-pulse">
                      Gemini is scanning the medical text, dosages, and daily timings.
                    </p>
                    <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                      <div className="bg-teal-500 h-full w-2/3 rounded-full animate-pulse"></div>
                    </div>
                  </div>
                )}

                {/* Error Banner */}
                {uploadError && (
                  <div className="p-3 bg-rose-50 border border-rose-100 text-rose-800 rounded-xl text-[10px] leading-relaxed flex items-start gap-1.5 text-left">
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                    <div>
                      <strong className="font-bold">Analysis Failed:</strong> {uploadError}
                    </div>
                  </div>
                )}

                {/* Analysis Results */}
                {extractedMeds && (
                  <div className="space-y-3 animate-fade-in text-left">
                    <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider font-mono flex items-center justify-between">
                      <span>AI Extracted Schedule</span>
                      <span className="text-teal-600 font-extrabold">
                        {extractedMeds.length} items found
                      </span>
                    </div>

                    <div className="space-y-2 max-h-[160px] overflow-y-auto pr-1">
                      {extractedMeds.map((med, idx) => (
                        <div
                          key={idx}
                          className="p-3 bg-white border border-slate-100 rounded-xl space-y-1.5 relative hover:border-teal-200 transition-all"
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <p className="text-xs font-bold text-slate-800 flex items-center gap-1">
                                <FileText className="w-3.5 h-3.5 text-teal-600" />
                                {med.medicationName}
                              </p>
                              <p className="text-[10px] text-slate-500">
                                Dosage: <span className="font-bold text-slate-700">{med.dosage}</span> • {med.frequency}
                              </p>
                            </div>
                            <span className="text-[9px] font-extrabold px-1.5 py-0.5 rounded-md bg-slate-100 text-slate-700 uppercase">
                              {med.slot}
                            </span>
                          </div>
                          {med.instructions && (
                            <p className="text-[9px] text-teal-800 bg-teal-50/50 px-2 py-1 rounded border border-teal-100/20 leading-relaxed">
                              💡 {med.instructions}
                            </p>
                          )}
                        </div>
                      ))}
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-2">
                      <button
                        onClick={() => {
                          setUploadedFile(null);
                          setExtractedMeds(null);
                        }}
                        className="py-2 px-3 bg-white hover:bg-slate-50 text-slate-600 border border-slate-200 rounded-xl text-xs font-bold cursor-pointer"
                      >
                        Discard
                      </button>
                      <button
                        onClick={handleConfirmSchedule}
                        className="py-2 px-3 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        Apply Schedule
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="sleek-card space-y-4">
            <div className="flex items-center gap-2 border-b border-brand-border pb-3">
              <Sparkles className="w-5 h-5 text-brand-primary" />
              <h3 className="font-bold text-brand-text-dark text-sm md:text-base tracking-tight">
                AI Patient Companion
              </h3>
            </div>

            {latestVisitWithNotes ? (
              <div className="space-y-4 animate-fade-in" id="ai-companion-notes">
                <div className="p-4 bg-brand-primary-light border border-brand-primary/20 rounded-2xl space-y-2">
                  <div className="text-xs font-bold text-brand-primary flex items-center gap-1">
                    <Info className="w-3.5 h-3.5" />
                    Latest Active Care Guidelines
                  </div>
                  <p className="text-xs text-teal-950 leading-relaxed font-semibold">
                    {simplifiedNotesText || latestVisitWithNotes.simplifiedNotes}
                  </p>
                </div>

                <div className="text-[10px] text-brand-text-muted font-mono flex items-center gap-1 bg-slate-50 p-2.5 rounded-xl border border-brand-border">
                  <Calendar className="w-3.5 h-3.5 text-brand-text-muted" />
                  <span>
                    Guidelines extracted from the consultation on{' '}
                    <strong className="text-brand-text-dark">{latestVisitWithNotes.date}</strong> by{' '}
                    <strong className="text-brand-text-dark">{latestVisitWithNotes.doctorName}</strong>.
                  </span>
                </div>
              </div>
            ) : (
              <div className="py-12 text-center text-brand-text-muted text-xs">
                <Sparkles className="w-8 h-8 text-slate-200 mx-auto mb-2" />
                <p>No active simplified notes. Log a doctor visit with raw clinical notes to activate Gemini AI guidance.</p>
              </div>
            )}
          </div>

          {/* Quick Care Tips Panel */}
          <div className="bg-gradient-to-br from-teal-800 to-emerald-950 rounded-[20px] p-6 text-white shadow-sm space-y-4">
            <h4 className="font-bold text-white text-sm tracking-tight flex items-center gap-1.5">
              <Coffee className="w-4 h-4 text-teal-300" />
              Healthy Living Recommendations
            </h4>
            <ul className="space-y-2.5 text-xs text-teal-100/95 leading-relaxed list-disc list-inside">
              <li>Always complete the entire course of prescribed antibiotics even if symptoms resolve.</li>
              <li>Take tablets with a full glass of lukewarm water unless instructed otherwise.</li>
              <li>Avoid taking pain relievers like Ibuprofen on an empty stomach to prevent irritation.</li>
              <li>Maintain regular hydration during infections (at least 8-10 glasses of fluid daily).</li>
            </ul>
          </div>

          {/* Live WhatsApp Smartphone Simulator Panel */}
          {currentUser && (
            <div className="bg-white border border-slate-200 rounded-[28px] p-5 shadow-lg space-y-4 relative overflow-hidden" id="whatsapp-simulator-container">
              {/* Header Info */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="space-y-0.5">
                  <h4 className="font-extrabold text-slate-900 text-sm tracking-tight flex items-center gap-1.5">
                    <Smartphone className="w-4 h-4 text-teal-600" />
                    WhatsApp Simulator
                  </h4>
                  <p className="text-[10px] text-brand-text-muted font-mono">
                    Incoming Alerts for {currentUser.name}
                  </p>
                </div>
                {pendingCount > 0 ? (
                  <span className="bg-teal-100 text-teal-800 text-[9px] font-bold px-2 py-0.5 rounded-full font-mono flex items-center gap-1 animate-pulse">
                    <span className="w-1.5 h-1.5 bg-teal-500 rounded-full"></span>
                    {pendingCount} Scheduled
                  </span>
                ) : (
                  <span className="bg-slate-100 text-slate-500 text-[9px] font-bold px-2 py-0.5 rounded-full font-mono">
                    Idle Queue
                  </span>
                )}
              </div>

              {/* Smartphone Frame Container */}
              <div className="bg-[#e5ddd5] border border-slate-300 rounded-[22px] overflow-hidden flex flex-col h-[340px] shadow-inner relative">
                {/* Smartphone Screen Top Bar */}
                <div className="bg-[#075e54] text-white px-3 py-2 flex items-center justify-between shadow">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-emerald-500/30 border border-white/20 flex items-center justify-center text-xs font-bold text-white uppercase shadow-sm">
                      CL
                    </div>
                    <div>
                      <div className="text-[11px] font-extrabold tracking-tight">CareLoop Alert Bot</div>
                      <div className="text-[9px] text-teal-100 flex items-center gap-1 font-semibold">
                        <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse"></span>
                        <span>online</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-[10px] font-bold text-teal-100 bg-[#128c7e] px-2 py-0.5 rounded-full font-mono">
                    +1 415-523-8886
                  </div>
                </div>

                {/* Smartphone Messages Body Scrollable */}
                <div 
                  className="flex-1 p-3 overflow-y-auto space-y-2.5 flex flex-col" 
                  style={{ 
                    backgroundImage: "url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png')", 
                    backgroundSize: 'contain',
                    backgroundColor: '#e5ddd5'
                  }}
                >
                  {waLogs.length === 0 ? (
                    <div className="my-auto text-center p-4 bg-white/95 backdrop-blur-sm rounded-2xl border border-slate-100 shadow-sm max-w-[240px] mx-auto space-y-1">
                      <p className="text-xs font-bold text-slate-800">No Messages Received</p>
                      <p className="text-[10px] text-slate-500 leading-normal">
                        Click <strong className="text-teal-700">"Simulate Missed Dose"</strong> on an unchecked medication above to trigger the 3-stage reminder cascade.
                      </p>
                    </div>
                  ) : (
                    waLogs.map((msg, i) => (
                      <div
                        key={i}
                        className="max-w-[85%] self-start bg-white rounded-xl rounded-tl-none p-2.5 shadow-sm border border-slate-200/40 space-y-1.5 text-xs animate-fade-in relative text-left"
                        id={`wa-msg-bubble-${i}`}
                      >
                        <div className="whitespace-pre-wrap text-slate-800 leading-relaxed font-semibold">
                          {msg.body.split('\n').map((line: string, index: number) => {
                            const formatted = line.replace(/\*(.*?)\*/g, '$1');
                            return (
                              <div key={index} className={line.startsWith('👉') ? 'mt-1 text-teal-700 font-extrabold break-all underline' : ''}>
                                {formatted}
                              </div>
                            );
                          })}
                        </div>
                        <div className="text-[9px] text-slate-400 font-mono font-bold text-right flex items-center justify-end gap-1 select-none">
                          <span>{msg.timestamp || 'Scheduled'}</span>
                          <CheckCheck className="w-3.5 h-3.5 text-sky-500" />
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Simulation Quick Controls */}
              <div className="space-y-2">
                <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider font-mono flex items-center justify-between">
                  <span>Simulation Accelerators</span>
                  <span className="text-teal-600 font-extrabold font-mono">
                    Interval: 5 mins
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={handleFastForward}
                    disabled={pendingCount === 0}
                    className={`py-2 px-3 border rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all outline-none focus:ring-2 ${
                      pendingCount > 0
                        ? 'bg-teal-600 hover:bg-teal-700 text-white border-teal-500 shadow-sm cursor-pointer hover:scale-[1.01]'
                        : 'bg-slate-50 text-slate-400 border-slate-200 cursor-not-allowed'
                    }`}
                    title="Advance simulation by 5 minutes to dispatch the next scheduled alert instantly"
                    id="ff-btn"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${pendingCount > 0 ? 'animate-spin-slow' : ''}`} />
                    Advance 5 Mins
                  </button>
                  <button
                    onClick={handleResetLogs}
                    className="py-2 px-3 bg-white hover:bg-slate-50 text-slate-600 hover:text-slate-800 border border-slate-200 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all outline-none hover:scale-[1.01]"
                    id="reset-logs-btn"
                  >
                    Clear Logs
                  </button>
                </div>
                {pendingCount > 0 && (
                  <div className="p-2.5 bg-amber-50 border border-amber-100 rounded-xl text-[10px] text-amber-800 font-medium leading-relaxed animate-pulse text-left">
                    ⏳ <strong>{pendingCount} remaining alert(s)</strong> scheduled in the background. They will dispatch automatically, or click <strong>"Advance 5 Mins"</strong> to fast-forward.
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Disease Recovery & Cured Early Management */}
      <div className="sleek-card p-6 md:p-8 space-y-6 mt-8" id="disease-recovery-panel">
        <div>
          <h3 className="font-bold text-brand-text-dark text-base tracking-tight flex items-center gap-2">
            <CheckCircle2 className="w-5.5 h-5.5 text-emerald-600" />
            Disease Recovery Status & Early Dismissal
          </h3>
          <p className="text-xs text-brand-text-muted mt-1">
            If your symptoms have cleared up early (e.g., in less than half of the prescribed course), you can mark the disease as cured to safely end daily medication reminders.
          </p>
        </div>

        {visits.length === 0 ? (
          <div className="py-8 text-center text-brand-text-muted text-xs border border-dashed border-brand-border rounded-2xl">
            No active prescriptions to manage recovery status for.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {visits.flatMap(visit => 
              visit.medications.map(med => {
                const isCured = curedMedications.includes(med.name);
                
                // Math calculations
                const today = new Date('2026-07-05');
                const rxDate = new Date(visit.date);
                const diffTime = today.getTime() - rxDate.getTime();
                const elapsedDays = Math.max(0, Math.floor(diffTime / (1000 * 60 * 60 * 24)));
                
                const durationMatch = med.duration.match(/(\d+)/);
                const durationDays = durationMatch ? parseInt(durationMatch[1], 10) : 7;
                const halfDuration = durationDays / 2;
                const isWithinHalfDuration = elapsedDays <= halfDuration;

                return (
                  <div 
                    key={`${visit.id}-${med.name}`}
                    className={`p-5 border rounded-2xl flex flex-col justify-between gap-4 transition-all ${
                      isCured
                        ? 'bg-emerald-50/20 border-emerald-200'
                        : 'bg-white border-brand-border hover:border-slate-300 hover:shadow-sm'
                    }`}
                  >
                    <div className="space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider font-mono">
                          Prescribed: {visit.date} ({elapsedDays} days ago)
                        </span>
                        {isCured ? (
                          <span className="bg-emerald-100 text-emerald-800 text-[9px] font-bold px-2 py-0.5 rounded-full uppercase font-mono">
                            Cured Early!
                          </span>
                        ) : isWithinHalfDuration ? (
                          <span className="bg-amber-100 text-amber-800 text-[9px] font-bold px-2.5 py-0.5 rounded-full uppercase font-mono">
                            Half-Course Active
                          </span>
                        ) : null}
                      </div>

                      <h4 className="font-bold text-brand-text-dark text-sm leading-tight">
                        {med.name}
                      </h4>
                      <p className="text-[11px] text-brand-text-muted">
                        Prescribed for: <strong className="text-slate-600">{visit.diagnosis}</strong> ({med.duration})
                      </p>

                      <div className="text-[10px] text-brand-text-muted mt-2 space-y-1 bg-slate-50 p-3 rounded-xl border border-slate-100 font-mono">
                        <div>Prescribed Course: <span className="font-bold text-brand-text-dark">{durationDays} days</span></div>
                        <div>Half-Duration Goal: <span className="font-bold text-brand-text-dark">{halfDuration} days</span></div>
                        <div>Days Elapsed So Far: <span className="font-bold text-brand-text-dark">{elapsedDays} days</span></div>
                        
                        {!isCured && (
                          <div className="mt-2 font-bold text-[10px]">
                            {isWithinHalfDuration ? (
                              <span className="text-emerald-600 flex items-center gap-1">
                                ● Within early-cure limit! Complete recovery target met.
                              </span>
                            ) : (
                              <span className="text-slate-400 font-normal">
                                ● Course is more than half finished.
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    </div>

                    {!isCured ? (
                      <button
                        onClick={() => {
                          onCureMedication(med.name);
                          if (isWithinHalfDuration) {
                            alert(`🎉 Amazing! You successfully completed your therapy and marked ${med.name} as cured within half the prescribed duration! Daily reminders for this medication have been deactivated.`);
                          } else {
                            alert(`🎉 You've marked ${med.name} as cured. Daily reminders for this medication have been deactivated.`);
                          }
                        }}
                        className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-sm shadow-emerald-600/15 transition-all uppercase"
                        id={`cure-btn-${med.name.replace(/\s+/g, '-').toLowerCase()}`}
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        I am Cured! End Reminders
                      </button>
                    ) : (
                      <div className="text-xs text-emerald-600 font-bold flex items-center justify-center gap-1.5 bg-emerald-50 border border-emerald-100 py-2.5 rounded-xl">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        Reminders Safely Deactivated
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        )}
      </div>
    </div>
  );
}
