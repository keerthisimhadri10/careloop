import React, { useState } from 'react';
import { SymptomCheckIn } from '../types';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import { Sparkles, AlertCircle, Heart, Calendar, FileText, Send, CheckCircle2 } from 'lucide-react';

interface SymptomCheckInProps {
  checkIns: SymptomCheckIn[];
  onAddCheckIn: (rating: number, note: string) => void;
}

const EMOJIS = [
  { rating: 1, char: '😫', label: 'Very Bad', color: 'bg-rose-50 border-rose-200 text-rose-700 hover:bg-rose-100' },
  { rating: 2, char: '🙁', label: 'Bad', color: 'bg-orange-50 border-orange-200 text-orange-700 hover:bg-orange-100' },
  { rating: 3, char: '😐', label: 'Okay', color: 'bg-amber-50 border-amber-200 text-amber-700 hover:bg-amber-100' },
  { rating: 4, char: '🙂', label: 'Good', color: 'bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100' },
  { rating: 5, char: '😄', label: 'Excellent', color: 'bg-teal-50 border-teal-200 text-teal-700 hover:bg-teal-100' },
];

export default function SymptomCheckInView({ checkIns, onAddCheckIn }: SymptomCheckInProps) {
  const [selectedRating, setSelectedRating] = useState<number>(4);
  const [note, setNote] = useState<string>('');
  const [successMsg, setSuccessMsg] = useState<boolean>(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddCheckIn(selectedRating, note);
    setNote('');
    setSuccessMsg(true);
    setTimeout(() => {
      setSuccessMsg(false);
    }, 4000);
  };

  // Check if rating drops for 3+ consecutive days
  const checkDecliningTrend = (): boolean => {
    if (checkIns.length < 3) return false;

    // Sort checkins ascending by date
    const sorted = [...checkIns].sort((a, b) => a.date.localeCompare(b.date));
    const n = sorted.length;

    // We check the last 3 check-ins
    const last = sorted[n - 1];
    const secondLast = sorted[n - 2];
    const thirdLast = sorted[n - 3];

    // If ratings are strictly decreasing
    if (thirdLast.rating > secondLast.rating && secondLast.rating > last.rating) {
      return true;
    }

    return false;
  };

  const hasDeclineAlert = checkDecliningTrend();

  // Prepare chart data (sorted by date ascending)
  const chartData = [...checkIns]
    .sort((a, b) => a.date.localeCompare(b.date))
    .map((c) => {
      // Format date e.g. "07-01" from "2026-07-01"
      const dateParts = c.date.split('-');
      const formattedDate = dateParts.length === 3 ? `${dateParts[1]}/${dateParts[2]}` : c.date;

      return {
        date: formattedDate,
        fullDate: c.date,
        rating: c.rating,
        note: c.note,
      };
    });

  // Custom Tooltip component for Recharts
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      const emojiObj = EMOJIS.find((e) => e.rating === data.rating);

      return (
        <div className="bg-slate-900 text-white p-4.5 rounded-2xl shadow-xl border border-slate-800 text-xs max-w-xs space-y-1 animate-fade-in">
          <div className="flex items-center justify-between gap-4 border-b border-slate-800 pb-1.5 mb-1.5">
            <span className="font-mono text-slate-400 font-bold">{data.fullDate}</span>
            <span className="text-base">{emojiObj?.char}</span>
          </div>
          <div className="font-bold flex items-center gap-1">
            Status: <span className="text-brand-primary">{emojiObj?.label} ({data.rating}/5)</span>
          </div>
          {data.note && (
            <div className="text-slate-300 italic mt-1 leading-relaxed">
              "{data.note}"
            </div>
          )}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6" id="symptom-check-in-view">
      {/* Declanining Trend Alert Banner */}
      {hasDeclineAlert && (
        <div className="bg-rose-50 border border-rose-200/60 rounded-3xl p-5 text-rose-800 shadow-sm flex items-start gap-3.5 animate-bounce-subtle" id="decline-alert-banner">
          <div className="p-2.5 bg-rose-100 rounded-2xl text-rose-700 shrink-0">
            <AlertCircle className="w-5.5 h-5.5" />
          </div>
          <div className="space-y-1">
            <h3 className="font-bold tracking-tight text-sm md:text-base text-rose-900">Health Rating Decline Detected</h3>
            <p className="text-xs text-rose-700 leading-relaxed font-medium">
              Our automated tracker has noticed a continuous decline in how you have been feeling over the last 3 days. Please consider contacting <strong className="text-rose-900 font-bold">Dr. Sarah Jenkins</strong> or checking in with your care provider sooner if your symptoms are worsening.
            </p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Daily Check-In Form */}
        <div className="lg:col-span-5 sleek-card space-y-6 self-start">
          <div>
            <h2 className="font-bold text-brand-text-dark text-lg tracking-tight">Daily Wellness Check-In</h2>
            <p className="text-xs text-brand-text-muted">Log how you feel today. Regular tracking helps identify positive recovery trends.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Rating Picker */}
            <div className="space-y-2.5">
              <label className="block text-xs font-bold text-brand-text-muted uppercase tracking-wider">
                How are you feeling today?
              </label>

              <div className="flex justify-between gap-1.5">
                {EMOJIS.map((emoji) => {
                  const isSelected = selectedRating === emoji.rating;
                  return (
                    <button
                      key={emoji.rating}
                      type="button"
                      id={`emoji-btn-${emoji.rating}`}
                      onClick={() => setSelectedRating(emoji.rating)}
                      className={`flex-1 flex flex-col items-center p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                        isSelected
                          ? 'border-brand-primary bg-brand-primary-light text-brand-primary scale-105 ring-2 ring-brand-primary-light font-bold'
                          : 'border-brand-border hover:bg-slate-50 text-brand-text-muted'
                      }`}
                    >
                      <span className="text-2xl mb-1.5">{emoji.char}</span>
                      <span className="text-[10px] font-bold leading-tight">{emoji.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Symptoms Note */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-brand-text-muted uppercase tracking-wider">
                Optional Notes / Symptoms
              </label>
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Describe any symptoms, fatigue level, pain points, or improvements (e.g. slight headache, minor fever, feeling fully recovered)."
                rows={4}
                className="w-full px-4 py-3 bg-slate-50 border border-brand-border rounded-2xl text-xs text-brand-text-dark focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary leading-relaxed font-semibold"
              ></textarea>
            </div>

            {/* Success and Submit */}
            {successMsg && (
              <div className="p-3 bg-emerald-50 border border-emerald-100 rounded-xl flex items-center gap-2 text-xs font-bold text-emerald-800 animate-fade-in">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Wellness report saved successfully!</span>
              </div>
            )}

            <button
              type="submit"
              className="w-full sleek-button"
              id="btn-submit-checkin"
            >
              <Send className="w-3.5 h-3.5" />
              Save Daily Report
            </button>
          </form>

          {/* Prompt/Help card */}
          <div className="p-4 bg-slate-50/80 rounded-2xl flex gap-3 items-start border border-brand-border">
            <Heart className="w-5 h-5 text-brand-primary shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <h4 className="text-xs font-bold text-brand-text-dark">Visualizing Shifting Trends</h4>
              <p className="text-[11px] text-brand-text-muted leading-relaxed font-medium">
                To test the decline warning banner, try submitting consecutive lower ratings (e.g., rating of 3, then 2, then 1) to simulate active symptoms.
              </p>
            </div>
          </div>
        </div>

        {/* Chart Card */}
        <div className="lg:col-span-7 sleek-card flex flex-col space-y-4">
          <div className="flex items-center justify-between border-b border-brand-border pb-4">
            <div>
              <h3 className="font-bold text-brand-text-dark text-base tracking-tight">Symptom & Wellness Trend</h3>
              <p className="text-xs text-brand-text-muted">Feeling metrics tracked over past visits duration.</p>
            </div>
            <div className="flex items-center gap-1 text-[11px] font-mono font-bold text-brand-primary bg-brand-primary-light px-2.5 py-1 rounded-lg border border-brand-primary/20">
              <Calendar className="w-3.5 h-3.5" />
              14-Day View
            </div>
          </div>

          {/* Recharts container */}
          <div className="h-80 w-full" id="trend-line-chart">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={chartData}
                margin={{ top: 15, right: 15, left: -20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis
                  dataKey="date"
                  tickLine={false}
                  axisLine={false}
                  tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 500 }}
                />
                <YAxis
                  domain={[1, 5]}
                  ticks={[1, 2, 3, 4, 5]}
                  tickLine={false}
                  axisLine={false}
                  tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 500 }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Line
                  type="monotone"
                  dataKey="rating"
                  stroke="#0d9488"
                  strokeWidth={3}
                  dot={{ r: 4, strokeWidth: 1, fill: '#fff', stroke: '#0d9488' }}
                  activeDot={{ r: 6, fill: '#0d9488', strokeWidth: 0 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Check-In list log feed */}
          <div className="space-y-3 pt-2">
            <div className="text-xs font-bold text-brand-text-muted uppercase tracking-wider flex items-center gap-1">
              <FileText className="w-3.5 h-3.5" />
              Recent Logs Feed
            </div>

            <div className="max-h-40 overflow-y-auto space-y-2.5 pr-1">
              {[...checkIns]
                .sort((a, b) => b.date.localeCompare(a.date))
                .map((log, index) => {
                  const emoji = EMOJIS.find((e) => e.rating === log.rating);
                  return (
                    <div
                      key={index}
                      className="p-3 bg-slate-50/50 border border-brand-border rounded-xl flex items-center justify-between gap-4 text-xs font-semibold"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="text-xl">{emoji?.char}</span>
                        <div>
                          <div className="font-bold text-brand-text-dark">
                            {emoji?.label} ({log.rating}/5)
                          </div>
                          {log.note && (
                            <div className="text-[10px] text-brand-text-muted font-semibold italic truncate max-w-[200px] sm:max-w-[320px]">
                              "{log.note}"
                            </div>
                          )}
                        </div>
                      </div>
                      <span className="text-[10px] font-mono text-brand-text-muted font-bold">
                        {log.date}
                      </span>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
