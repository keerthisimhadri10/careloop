import { Doctor, Visit, SymptomCheckIn, MedicationTask, Appointment } from './types';

export const SAMPLE_DOCTORS: Doctor[] = [
  {
    id: 'doc-1',
    name: 'Dr. Sarah Jenkins',
    specialty: 'General Physician',
    rating: 4.9,
    experience: '12 years',
    hospital: 'Metro Family Health',
    availableDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
    availableSlots: ['09:00 AM', '10:00 AM', '11:00 AM', '02:00 PM', '03:00 PM', '04:00 PM']
  },
  {
    id: 'doc-2',
    name: 'Dr. Michael Chen',
    specialty: 'Cardiologist',
    rating: 4.8,
    experience: '15 years',
    hospital: 'Heart & Vascular Institute',
    availableDays: ['Mon', 'Wed', 'Thu'],
    availableSlots: ['09:30 AM', '10:30 AM', '11:30 AM', '01:30 PM', '02:30 PM', '03:30 PM']
  },
  {
    id: 'doc-3',
    name: 'Dr. Amanda Ross',
    specialty: 'Dermatologist',
    rating: 4.7,
    experience: '8 years',
    hospital: 'Skin & Laser Center',
    availableDays: ['Tue', 'Thu', 'Fri'],
    availableSlots: ['09:00 AM', '10:30 AM', '11:00 AM', '02:00 PM', '03:30 PM', '04:30 PM']
  },
  {
    id: 'doc-4',
    name: 'Dr. David Patel',
    specialty: 'Pediatrician',
    rating: 4.9,
    experience: '10 years',
    hospital: 'St. Jude Children Clinic',
    availableDays: ['Mon', 'Tue', 'Thu', 'Fri'],
    availableSlots: ['08:30 AM', '10:00 AM', '11:30 AM', '01:00 PM', '03:00 PM', '04:00 PM']
  },
  {
    id: 'doc-5',
    name: 'Dr. Elena Rostova',
    specialty: 'Neurologist',
    rating: 4.9,
    experience: '18 years',
    hospital: 'Brain & Spine Specialty Hosp',
    availableDays: ['Wed', 'Fri'],
    availableSlots: ['10:00 AM', '11:00 AM', '02:00 PM', '03:00 PM', '04:00 PM']
  }
];

export const SAMPLE_APPOINTMENTS: Appointment[] = [
  {
    id: 'appt-pre-1',
    doctorId: 'doc-1',
    doctorName: 'Dr. Sarah Jenkins',
    specialty: 'General Physician',
    date: '2026-07-01',
    slot: '10:00 AM',
    status: 'completed'
  },
  {
    id: 'appt-pre-2',
    doctorId: 'doc-3',
    doctorName: 'Dr. Amanda Ross',
    specialty: 'Dermatologist',
    date: '2026-07-03',
    slot: '02:00 PM',
    status: 'completed'
  }
];

export const SAMPLE_VISITS: Visit[] = [
  {
    id: 'visit-1',
    doctorId: 'doc-3',
    doctorName: 'Dr. Amanda Ross',
    specialty: 'Dermatologist',
    date: '2026-07-03',
    diagnosis: 'Acute Contact Dermatitis',
    rawNotes: 'Pt presents with red, itchy rash on left forearm. Appeared after hiking. Appears to be poison ivy contact. Rx: Hydrocortisone 2.5% cream, apply thin layer bid for 7 days. Also Cetirizine 10mg po qd prn for itching x 10 days. Avoid scratching to prevent secondary infection. F/u in 2 weeks if not resolving.',
    simplifiedNotes: 'You have a skin allergy (contact dermatitis) likely caused by contact with an irritating plant like poison ivy. To help it heal, apply the prescribed Hydrocortisone cream in a thin layer twice a day for a week. If you experience severe itching, you can take one Cetirizine allergy pill daily. Keep the area clean and do not scratch it to avoid any secondary skin infections. If it does not improve, follow up in two weeks.',
    medications: [
      {
        name: 'Hydrocortisone 2.5% cream',
        dosage: 'Thin layer',
        frequency: 'twice daily',
        duration: '7 days',
        slots: ['morning', 'evening']
      },
      {
        name: 'Cetirizine 10mg',
        dosage: '1 tablet',
        frequency: 'once daily as needed',
        duration: '10 days',
        slots: ['morning']
      }
    ],
    followUpDate: '2026-07-17'
  },
  {
    id: 'visit-2',
    doctorId: 'doc-1',
    doctorName: 'Dr. Sarah Jenkins',
    specialty: 'General Physician',
    date: '2026-07-01',
    diagnosis: 'Streptococcal Pharyngitis (Strep Throat)',
    rawNotes: 'Sudden onset of severe sore throat, fever 101.3 F, tonsillar exudates, tender anterior cervical lymph nodes. Rapid strep test (+). Rx: Amoxicillin 500mg po bid x 10 days. Ibuprofen 400mg po q4-6h prn pain/fever. Warm saltwater gargles. Rest, push fluids. F/u in 3 days if fever persists.',
    simplifiedNotes: 'You have Strep Throat, a bacterial infection. You must complete the full 10-day course of Amoxicillin (twice daily) even if you start feeling better sooner. Take Ibuprofen every 4 to 6 hours as needed for throat pain or fever. Drink plenty of warm water, gargle warm salt water to soothe your throat, and get lots of rest.',
    medications: [
      {
        name: 'Amoxicillin 500mg',
        dosage: '1 capsule',
        frequency: 'twice daily',
        duration: '10 days',
        slots: ['morning', 'evening']
      },
      {
        name: 'Ibuprofen 400mg',
        dosage: '1 tablet',
        frequency: 'every 4-6 hours as needed',
        duration: '5 days',
        slots: ['morning', 'afternoon', 'evening']
      }
    ],
    followUpDate: '2026-07-08' // within 3 days of today's date (July 5th, 2026) -> Triggering the Follow-up Reminder Banner!
  }
];

export const SAMPLE_MEDICATION_TASKS: MedicationTask[] = [
  { id: 't-1', medicationName: 'Amoxicillin 500mg', dosage: '1 capsule', slot: 'morning', checked: true },
  { id: 't-2', medicationName: 'Amoxicillin 500mg', dosage: '1 capsule', slot: 'evening', checked: false },
  { id: 't-3', medicationName: 'Ibuprofen 400mg', dosage: '1 tablet', slot: 'morning', checked: true },
  { id: 't-4', medicationName: 'Ibuprofen 400mg', dosage: '1 tablet', slot: 'afternoon', checked: false },
  { id: 't-5', medicationName: 'Ibuprofen 400mg', dosage: '1 tablet', slot: 'evening', checked: false },
  { id: 't-6', medicationName: 'Hydrocortisone cream', dosage: 'Thin layer', slot: 'morning', checked: true },
  { id: 't-7', medicationName: 'Hydrocortisone cream', dosage: 'Thin layer', slot: 'evening', checked: false }
];

// 7-10 days of feeling ratings from 2026-06-25 to 2026-07-04
// 1 = very bad, 5 = very good
export const SAMPLE_CHECKINS: SymptomCheckIn[] = [
  { date: '2026-06-25', rating: 4, note: 'Feeling pretty healthy, mild throat tickle.' },
  { date: '2026-06-26', rating: 4, note: 'Normal day, went jogging.' },
  { date: '2026-06-27', rating: 3, note: 'Slight fever in evening, scratchy throat.' },
  { date: '2026-06-28', rating: 2, note: 'Woke up with bad sore throat and fever.' },
  { date: '2026-06-29', rating: 1, note: 'Throat extremely painful, could barely swallow.' },
  { date: '2026-06-30', rating: 2, note: 'Stressed, throat still very sore.' },
  { date: '2026-07-01', rating: 2, note: 'Saw Dr. Jenkins, got antibiotics.' },
  { date: '2026-07-02', rating: 3, note: 'Fever gone, starting to feel better.' },
  { date: '2026-07-03', rating: 4, note: 'Antibiotics working, skin itchy from hiking though.' },
  { date: '2026-07-04', rating: 4, note: 'Skin rash on arm, otherwise feeling much better!' }
];
