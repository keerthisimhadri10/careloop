export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  rating: number;
  experience: string;
  hospital: string;
  availableDays: string[]; // ['Mon', 'Tue', 'Wed', 'Thu', 'Fri']
  availableSlots: string[]; // ['09:00 AM', '10:00 AM', ...]
}

export interface Appointment {
  id: string;
  doctorId: string;
  doctorName: string;
  specialty: string;
  date: string; // YYYY-MM-DD
  slot: string; // e.g. "10:00 AM"
  status: 'upcoming' | 'completed';
  paymentId?: string;
  amountPaid?: number;
}

export interface Medication {
  name: string;
  dosage: string;
  frequency: string;
  duration: string;
  slots: ('morning' | 'afternoon' | 'evening')[];
}

export interface Visit {
  id: string;
  doctorId: string;
  doctorName: string;
  specialty: string;
  date: string; // YYYY-MM-DD
  diagnosis: string;
  rawNotes: string;
  simplifiedNotes?: string;
  medications: Medication[];
  followUpDate?: string; // YYYY-MM-DD
}

export interface SymptomCheckIn {
  date: string; // YYYY-MM-DD
  rating: number; // 1 to 5
  note: string;
}

export interface MedicationTask {
  id: string;
  medicationName: string;
  dosage: string;
  slot: 'morning' | 'afternoon' | 'evening';
  checked: boolean;
}

export interface CareState {
  doctors: Doctor[];
  appointments: Appointment[];
  visits: Visit[];
  checkIns: SymptomCheckIn[];
  medicationTasks: MedicationTask[];
  simplifiedNotesText?: string;
}
